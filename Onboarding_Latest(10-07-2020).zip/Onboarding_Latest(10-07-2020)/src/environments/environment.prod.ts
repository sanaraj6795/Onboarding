 export const environment = {
   production: true,
   apiBaseUrl: "https://cognizantonline.sharepoint.com/sites/TestWeb/",
   appWebUrl: "https://cognizantonline.sharepoint.com/sites/TestWeb/Shared%20Documents/Saranya/index.aspx",
   emailFrom: "Thirumalaivasan.S2@Cognizant.com",
   onboardingListAccessGroupName: "OnboardingListAccess",
   onboardingAppAccessGroupName: "OnboardingAppAccess",
   onboardingAdminGroupName: "OnboardingAdmin",
   resourceMasterAdminGroupName: "ResourceMasterAdmin"
 };

/*export const environment = {
  production: true,
  apiBaseUrl: "https://cognizantonline.sharepoint.com/sites/ukInsurance/RLG/",
  appWebUrl: "https://cognizantonline.sharepoint.com/sites/ukInsurance/RLG/Pages/Onboarding/Live/index.aspx",
  emailFrom: "Thirumalaivasan.S2@Cognizant.com",
  onboardingListAccessGroupName: "OnboardingListAccess",
  onboardingAppAccessGroupName: "OnboardingAppAccess",
  onboardingAdminGroupName: "OnboardingAdmin",
  resourceMasterAdminGroupName: "ResourceMasterAdmin"
};*/