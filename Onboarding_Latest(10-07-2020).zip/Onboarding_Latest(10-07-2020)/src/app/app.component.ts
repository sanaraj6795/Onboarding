import { Component } from '@angular/core';

import { ToasterConfig } from 'angular2-toaster';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'rlg-pmo-application';
  
  public config: ToasterConfig = 
  new ToasterConfig({
      showCloseButton: false, 
      tapToDismiss: false, 
      timeout: 2000
  });
}
