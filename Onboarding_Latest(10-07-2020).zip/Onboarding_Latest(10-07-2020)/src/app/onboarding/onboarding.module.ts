import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { BsDatepickerModule, PaginationModule, BsModalService, ProgressbarModule,  } from 'ngx-bootstrap';
import { ChartsModule } from 'ng2-charts';
import { ToasterModule } from 'angular2-toaster';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from '../app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { OnboardingRoutingModule } from './onboarding-routing.module';

import { AssociatePlanComponent } from './associate-plan/associate-plan.component';
import { DashBoardComponent } from './dashboard/dashboard.component';
import { CourseDetailsListComponent } from './course-group/summary/course-group-list.component';
import { CourseDetailsComponent } from './course-details/add-course/course-details.component';
import { CourseListComponent } from './course-details/summary/course-list.component';
import { AddCourseGroupComponent } from './course-group/add-course-group/add-course-group.component';
import { AddPlanDetailsComponent } from './plan-detail/add-plan-detail/add-plan-detail.component';
import { PlanSummaryComponent } from './plan-detail/summary.component';
import { AddCourseDialogComponent } from './course-group/search-course/search-course.component';
import { GroupViewComponent } from './course-group/course-detail-view/course-detail-view.component';
import { DatePipe } from '../providers/service/datepipe';
import { CourseDetailModelComponent } from './associate-plan/course-detail-model/course-detail-model.component';
import { ViewPlanProofComponent } from './associate-plan/view-plan-proof/view-plan-proof.component';
import { ViewUserPlanDetailComponent } from './plan-detail/view-user-plan-detail.component';
import { MigrationComponent } from './migration/migration.component';

@NgModule({
  declarations: [
    AssociatePlanComponent,
    DashBoardComponent,
    CourseListComponent,
    CourseDetailsComponent,
    AddCourseDialogComponent,
    GroupViewComponent,
    CourseDetailsListComponent,
    AddCourseGroupComponent,
    AddPlanDetailsComponent,
    PlanSummaryComponent,
    CourseDetailModelComponent,
    ViewPlanProofComponent,
    ViewUserPlanDetailComponent,
    MigrationComponent,
    DatePipe
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    ChartsModule,
    Ng4LoadingSpinnerModule.forRoot(),
    BsDatepickerModule.forRoot(),
    PaginationModule.forRoot(),
    ProgressbarModule.forRoot(),
    ToasterModule.forRoot(),
    DragDropModule,
    OnboardingRoutingModule
  ],
  providers: [
    BsModalService,
  ],
  entryComponents: [
    AddCourseDialogComponent,
    GroupViewComponent,
    CourseDetailModelComponent,
    ViewPlanProofComponent,
    ViewUserPlanDetailComponent
  ]
})
export class OnboardingModule { }
