import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ToasterService } from 'angular2-toaster';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ICourseDetail } from 'src/app/providers/model/courseDetail';
import { IUserGroup } from 'src/app/providers/model/user-group';
import { AddCourseDialogComponent } from '../search-course/search-course.component';
import { CourseGroupService } from 'src/app/providers/service/onboarding/course-group.service';
import { environment } from 'src/environments/environment.prod';
import { CourseDetailsService } from 'src/app/providers/service/onboarding/course-details.service';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';

@Component({
    selector: 'app-user-role-details',
    templateUrl: './add-course-group.component.html',
    styleUrls: ['./add-course-group.component.scss']
})
export class AddCourseGroupComponent implements OnInit {
    userRoleForm: FormGroup;
    userGroup: IUserGroup[];
    userGroupObject: IUserGroup;
    userRoleId: string;
    courseCount: number;
    coursesAdded: ICourseDetail[] = [];
    mode: string;
    isAdmin: boolean = false;
    submitted = false;
    formDigestDetail: any;
    selectedList: any = [];
    allList: any;

    baseUrl = environment.apiBaseUrl;

    constructor(private fb: FormBuilder,
        private route: ActivatedRoute, private router: Router,
        private userRoleService: CourseGroupService,
        public dialog: MatDialog,
        private httpClient: HttpClient,
        private toasterService: ToasterService,
        private spinnerService: Ng4LoadingSpinnerService,
        private courseDetailsService: CourseDetailsService) {
    }

    ngOnInit() {
        this.getFormDigest();
        this.route.params.subscribe(params => { this.userRoleId = params["id"] });
        this.checkUserRole();
        this.buildForm();
        this.courseCount = this.coursesAdded.length;
        if (this.userRoleId != "" && this.userRoleId != undefined && this.userRoleId != null) {
            this.spinnerService.show();
            this.courseDetailsService.getAllCourse().subscribe(model => {
                this.allList = model.value;
                this.userRoleService.getCourseById(this.userRoleId)
                    .subscribe(modal => {
                        this.coursesAdded = modal.value.courseDetail;
                        this.userGroupObject = modal.value.userGroup;
                        let id = this.userGroupObject.CourseIds.split(',');
                        if (this.allList.length > 0 && id.length > 0) {
                            id.map(x => {
                                this.allList.map(y => {
                                    if (y.id == x) {
                                        this.selectedList.push(y.title);
                                    }
                                });
                            });

                            this.allList.forEach(x => {
                                this.selectedList.forEach(y => {
                                    if (y == x.title) {
                                        let val = this.allList.indexOf(x);
                                        this.allList[val].checked = true;
                                    }
                                });
                            });
                        }

                        this.mode = "Update";
                        this.bindData();
                        this.spinnerService.hide();
                    });
            });
        }
        else {
            this.mode = "Add";
            this.courseDetailsService.getAllCourse().subscribe(model => {
                this.allList = model.value;
            });
        }
    }

    openDialog(): void {
        this.submitted = true;
        if (this.userRoleForm.invalid) {
            return;
        }

        const dialogRef = this.dialog.open(AddCourseDialogComponent, {
            width: '70%',
            maxHeight: "700px",
            disableClose: true
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result != null) {

                result.forEach(e => {
                    this.coursesAdded.push(e);
                });
                this.courseCount = this.coursesAdded.length;
            }
        });
    }

    deleteCourseDetail(courseData: any): void {
        const index: number = this.coursesAdded.indexOf(courseData);
        if (index !== -1) {
            this.coursesAdded.splice(index, 1);
        }
        this.courseCount = this.coursesAdded.length;
    }

    private buildForm() {
        this.userRoleForm = this.fb.group({
            groupName: ['', [Validators.required]],
            groupCode: ['', [Validators.required]],
            groupDescription: ['', [Validators.required]],
        });
    }

    get f() { return this.userRoleForm.controls; }

    private checkUserRole() {
        this.userRoleService.get().subscribe(userRole => {
            this.userGroup = userRole;
            if (this.userGroup.find(i => i.GroupName == "Admin")) {
                this.isAdmin = true;
            }
        });
    }
    private bindData() {
        this.userRoleForm.setValue({
            groupName: this.userGroupObject.GroupName,
            groupCode: this.userGroupObject.GroupCode,
            groupDescription: this.userGroupObject.GroupDescription
        });
    }

    private resetForm() {
        this.userRoleForm.reset();
    }

    onSubmit() {
        this.submitted = true;
        if (this.userRoleForm.invalid && this.selectedList.length == 0) {
            return;
        }
        if (!this.userRoleForm.invalid && this.selectedList.length > 0) {
            if (this.mode == "Update") {
                this.updateCourseDetail();
            }
            else {
                this.addCourseDetail();
            }
        }
    }

    public addCourseDetail() {
        var courseIds = [];
        this.spinnerService.show();
        this.selectedList.forEach(x => {
            let value = this.allList.find(y => y.title == x);
            courseIds.push(value.id);
        });
        let listName = "OnboardingCourseGroup";
        var itemType = this.getItemTypeForListName(listName);
        var item = {
            "__metadata": { "type": itemType },
            "Title": this.userRoleForm.get('groupName').value,
            "GroupCode": this.userRoleForm.get('groupCode').value,
            "GroupDescription": this.userRoleForm.get('groupDescription').value,
            "CourseIds": courseIds.toString()
        };

        let httpHeaders = new HttpHeaders({
            'Content-Type': 'application/json;charset=UTF-8;odata=verbose',
            'Cache-Control': 'no-cache',
            'accept': 'application/json;odata=verbose',
            "X-HTTP-Method": "POST",
            "X-RequestDigest": this.formDigestDetail.FormDigestValue
        });
        let options = {
            headers: httpHeaders,
        };

        var siteUrl = this.baseUrl + "_api/lists/getbytitle('" + listName + "')/items";
        this.httpClient.post<any>(siteUrl, JSON.stringify(item), options).subscribe((response: Response) => {
            this.spinnerService.hide();
            this.toasterService.pop("success", "Course Group Details", "Course Group Details Added Successfully");
            this.router.navigate(['/onboarding/user-role-detail']);
        }, error => {
            this.spinnerService.hide();
            this.toasterService.pop("error", "Course Group Details", "Error Occurred While Adding Course Group Details");
            console.log(error);
        });
    }

    public updateCourseDetail() {
        var courseIds = [];
        this.spinnerService.show();
        this.selectedList.forEach(x => {
            let value = this.allList.find(y => y.title == x);
            courseIds.push(value.id);
        });
        let listName = "OnboardingCourseGroup";
        var itemType = this.getItemTypeForListName(listName);
        var item = {
            "__metadata": { "type": itemType },
            "Title": this.userRoleForm.get('groupName').value,
            "GroupCode": this.userRoleForm.get('groupCode').value,
            "GroupDescription": this.userRoleForm.get('groupDescription').value,
            "CourseIds": courseIds.toString()
        };

        let httpHeaders = new HttpHeaders({
            'Content-Type': 'application/json;charset=UTF-8;odata=verbose',
            'Cache-Control': 'no-cache',
            'Accept': 'application/json;odata=verbose',
            "X-HTTP-Method": "MERGE",
            "If-Match": "*",
            "X-RequestDigest": this.formDigestDetail.FormDigestValue
        });
        let options = {
            headers: httpHeaders,
        };

        var siteUrl = this.baseUrl + "_api/lists/getbytitle('" + listName + "')/items(" + this.userRoleId + ")";
        this.httpClient.post<any>(siteUrl, JSON.stringify(item), options).subscribe((response: Response) => {
            this.spinnerService.hide();
            this.toasterService.pop("success", "Course Group Details", "Course Group Updated Successfully");
            this.router.navigate(['/onboarding/user-role-detail']);
        }, error => {
            this.spinnerService.hide();
            this.toasterService.pop("error", "Course Group Details", "Error Occurred While Updating Course Group Details");
            console.log(error);
        });
    }

    public getItemTypeForListName(name) {
        return "SP.Data." + name.charAt(0).toUpperCase() + name.slice(1) + "ListItem";
    }

    public getFormDigest() {
        let options = {
            "accept": "application/json;odata=verbose",
            "contentType": "text/xml"
        };
        this.spinnerService.show();
        var siteUrl = this.baseUrl + "_api/contextinfo";
        this.httpClient.post(siteUrl, options).subscribe((response: Response) => {
            this.spinnerService.hide();
            this.formDigestDetail = response;
        }, error => {
            this.spinnerService.hide();
            console.log(error);
        });
    }

    addListItems() {
        //this.selectedList = this.courses.filter(opt => opt.checked).map(opt => opt.id);
        let intialSelectedItems = this.allList.filter(opt => opt.checked).map(opt => opt.title);
        if (this.selectedList.length > 0) {
            intialSelectedItems.map(item => {
                if (!this.selectedList.includes(item)) {
                    this.selectedList.push(item);
                }
            });

        }
        else {
            this.selectedList = intialSelectedItems;
        }
    }

    drop(event: CdkDragDrop<string[]>) {
        moveItemInArray(this.selectedList, event.previousIndex, event.currentIndex);
    }

    removeListItems() {
        this.selectedList = [];
        this.allList.forEach(x => { x.checked = false });
    }

    deleteCourse(removeCourse) {
        const index: number = this.selectedList.indexOf(removeCourse);
        if (index !== -1) {
            this.selectedList.splice(index, 1);
        }
        let foundedItem = this.allList.find(x => x.title == removeCourse);
        let courseIndex = this.allList.indexOf(foundedItem);
        this.allList[courseIndex].checked = false
    }
}