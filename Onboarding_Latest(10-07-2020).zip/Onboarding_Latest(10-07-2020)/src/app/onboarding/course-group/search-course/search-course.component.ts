import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Output, EventEmitter, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ICourseDetail } from 'src/app/providers/model/courseDetail';
import { CourseDetailsService } from 'src/app/providers/service/onboarding/course-details.service';

@Component({
  selector: 'app-add-course-dialog',
  templateUrl: './search-course.component.html',
  styleUrls: ['./search-course.component.scss']
})
export class AddCourseDialogComponent implements OnInit {
  courseForm: FormGroup;
  submitted = false;
  courses: ICourseDetail[];
  marked: false;
  selectedCourses: ICourseDetail[] = [];
  courseLength: number = 0;
  @Output() submitClicked = new EventEmitter<any>();
  courseType: Array<string> = [];
  documentType: Array<string> = ['Date', "File"];

  constructor(
    private courseDetailsService: CourseDetailsService,
    private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<AddCourseDialogComponent>,
    private spinnerService: Ng4LoadingSpinnerService) { }

  ngOnInit() {
    this.courseDetailsService.getCourseType().subscribe(model => {
      this.courseType = model.value;
    });

    this.courseForm = this.formBuilder.group({
      description: ['', [Validators.required]],
      courseName: ['', [Validators.required]]
    });
  }

  get f() { return this.courseForm.controls; }

  onSearch(formData: any) {
    this.submitted = true;
    if (this.courseForm.invalid) {
      return;
    }
    this.spinnerService.show();
    this.courses = [];
    this.courseDetailsService.getCourseSearch(this.courseForm.get('description').value, this.courseForm.get('courseName').value)
      .subscribe(model => {
        this.spinnerService.hide();
        this.courses = model;
        this.courseLength = this.courses.length;
      });
  }

  onAddSubmit() {
    this.dialogRef.close(this.selectedCourses);
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onClear() {
    this.formDataClear();
  }

  toggleVisibility(e, data: any) {
    this.marked = e.target.checked;
    if (this.marked) {
      this.selectedCourses.push(data);
    }
    else {
      let i = this.selectedCourses.indexOf(data);
      this.selectedCourses.splice(i, 1);
    }
  }

  private formDataClear() {
    this.courseForm.setValue({
      courseName: "",
      description: ""
    });
    this.submitted = false;
    this.courses = [];
  }
}