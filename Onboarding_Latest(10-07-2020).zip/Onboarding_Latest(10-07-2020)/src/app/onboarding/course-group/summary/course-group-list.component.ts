import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PageChangedEvent } from 'ngx-bootstrap';
import { MatDialog } from '@angular/material';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { IUserGroup } from 'src/app/providers/model/user-group';
import { GroupViewComponent } from '../course-detail-view/course-detail-view.component';
import { CoursesService } from 'src/app/providers/service/onboarding/course-group/courses.service';

@Component({
    selector: 'app-userrole',
    templateUrl: './course-group-list.component.html',
    styleUrls: []
})
export class CourseDetailsListComponent implements OnInit {

    courseList: IUserGroup[];
    currentPage: number = 0;
    totalItems: number;

    constructor(private router: Router, private coursesService: CoursesService,
        public dialog: MatDialog,
        private spinnerService: Ng4LoadingSpinnerService) {
    }

    ngOnInit() {
        this.getCourseList();
    }

    pageChanged(event: PageChangedEvent): void {
        this.currentPage = event.page - 1;
        this.getCourseList();
    }

    viewCourseGroupDetail(courseIds: string): void {

        const dialogRef = this.dialog.open(GroupViewComponent, {
            maxHeight: "700px",
            data: { courseIds: courseIds }
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result != null) {
            }
        });
    }

    private getCourseList() {
        this.spinnerService.show();
        const startItem = this.currentPage * 10;
        this.coursesService.getCourseGroup(startItem).subscribe(modal => {
            this.spinnerService.hide();
            this.courseList = modal.courseGroup
            this.totalItems = modal.count;
        });
    }
}