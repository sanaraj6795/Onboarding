import { Component, OnInit, Optional, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { IUserGroup } from 'src/app/providers/model/user-group';
import { ICourse } from 'src/app/providers/model/course';
import { CourseGroupService } from 'src/app/providers/service/onboarding/course-group.service';

@Component({
  selector: 'app-group-view',
  templateUrl: './course-detail-view.component.html',
  styleUrls: []
})
export class GroupViewComponent implements OnInit {
  fromPage: any;
  title: string;
  closeBtnName: string;
  list: any[] = [];
  groupDetails: IUserGroup;
  courseCount: number;
  courseList: ICourse[]=[];
  constructor(private coursesService: CourseGroupService,
    public dialogRef: MatDialogRef<GroupViewComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any,
    private spinnerService: Ng4LoadingSpinnerService) {
    this.fromPage = data.courseIds;
  }

  ngOnInit() {
    this.getCourseList();
  }
  
  onNoClick(): void {
    this.dialogRef.close();
  }

  private getCourseList() {
    this.spinnerService.show();
    this.coursesService.getCourseDetailsByIds(this.fromPage).subscribe(modal => {
      this.spinnerService.hide();
      this.courseList = modal.value;
      this.courseCount = modal.value.length;
    });
  }
}