import { Component, OnInit } from '@angular/core';
import { PageChangedEvent } from 'ngx-bootstrap';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ICourseDetail } from 'src/app/providers/model/courseDetail';
import { CourseDetailsService } from 'src/app/providers/service/onboarding/course-details.service';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.scss']
})
export class CourseListComponent implements OnInit {
  courseDetail: ICourseDetail[];
  currentPage: number = 0;
  currentItemId: number = 0;
  totalItems: number;

  constructor(private courseDetailService: CourseDetailsService,
    private spinnerService: Ng4LoadingSpinnerService) { }

  ngOnInit() {
    this.getCourseListDetails();
  }

  pageChanged(event: PageChangedEvent): void {
    this.currentPage = event.page - 1;
    this.getCourseListDetails();
  }

  private getCourseListDetails() {
    const startItem = this.currentPage * 10;
    this.spinnerService.show();
    this.courseDetailService.getCourses(startItem, this.currentItemId).subscribe(model => {
      this.spinnerService.hide();
      this.courseDetail = model.courseDetail;
      this.totalItems = model.count;
      this.currentItemId = +this.courseDetail[this.courseDetail.length - 1].id;
      console.log(this.currentItemId);;
    });
  }
}