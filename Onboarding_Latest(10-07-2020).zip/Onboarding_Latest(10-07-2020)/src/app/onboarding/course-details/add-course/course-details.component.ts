import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToasterService } from 'angular2-toaster';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ICourseDetail } from 'src/app/providers/model/courseDetail';
import { CourseDetailsService } from 'src/app/providers/service/onboarding/course-details.service';
import { environment } from 'src/environments/environment.prod';
import { HttpClientService } from 'src/app/providers/service/http-client.service';

@Component({
  selector: 'app-course-details',
  templateUrl: './course-details.component.html'
})
export class CourseDetailsComponent implements OnInit {
  courseId: string;
  mode: string;
  courseDetail: ICourseDetail;
  courseForm: FormGroup;
  submitted = false;
  status: string;
  formDigestDetail: any;
  courseType: Array<string> = [];
  documentType: Array<string> = ['Date', "File"];

  baseUrl = environment.apiBaseUrl;

  constructor(private route: ActivatedRoute,
    private router: Router,
    private formBuilder: FormBuilder,
    private courseDetailService: CourseDetailsService,
    private httpClientService: HttpClientService,
    private toasterService: ToasterService,
    private spinnerService: Ng4LoadingSpinnerService) { }

  ngOnInit() {

    this.courseDetailService.getCourseType().subscribe(model => {
      this.courseType = model.value;
    });

    this.getFormDigest();
    this.createForm();
    this.route.params.subscribe(params => {
      this.courseId = params["id"]
    });

    if (this.courseId != "" && this.courseId != undefined && this.courseId != null) {
      this.courseDetailService.getCourseById(this.courseId)
        .subscribe(model => {
          this.courseDetail = model.value;
          this.mode = "Update";
          this.bindData();
        });
    }
    else {
      this.mode = "Add";
    }
  }

  private getFormDigest() {
    this.spinnerService.show();
    this.httpClientService.getFormDigest().subscribe((response: Response) => {
      this.formDigestDetail = response;
      this.spinnerService.hide();
    }, error => {
      this.spinnerService.hide();
      console.log(error);
    });
  }

  createForm() {
    this.courseForm = this.formBuilder.group({
      title: ['', [Validators.required]],
      code: ['', [Validators.required]],
      url: ['', [Validators.required]],
      description: ['', [Validators.required]],
      docType: ['', [Validators.required]],
      courseType: ['', [Validators.required]]
    });
  }

  get f() { return this.courseForm.controls; }

  private bindData() {
    const result = Object.assign({}, this.courseDetail);
    this.courseForm.setValue({
      title: result.title,
      code: result.code,
      url: result.url,
      description: result.description,
      docType: result.documentType,
      courseType: result.courseType
    });
  }

  changeCourseType(e) {
    this.getCourseType.setValue(e.target.value, { onlySelf: true });
  }

  get getCourseType() {
    return this.courseForm.get('courseType');
  }

  changeDocumentType(e) {
    this.docType.setValue(e.target.value, { onlySelf: true });
  }

  get docType() {
    return this.courseForm.get('docType');
  }

  onSubmit() {
    this.submitted = true;
    if (this.courseForm.invalid) {
      return;
    }

    if (this.mode == "Update") {
      this.updateCourseDetail();
    }
    else {
      this.addCourseDetail();
    }
  }

  public addCourseDetail() {
    let listName = "OnboardingCourseDetail";
    var itemType = this.getItemTypeForListName(listName);
    var item = {
      "__metadata": { "type": itemType },
      "Title": this.courseForm.get('title').value,
      "Code": this.courseForm.get('code').value,
      "Reference": this.courseForm.get('url').value,
      "Description": this.courseForm.get('description').value,
      "CourseType": this.courseForm.get('courseType').value,
      "DocumentType": this.courseForm.get('docType').value
    };

    this.spinnerService.show();
    var siteUrl = this.baseUrl + "_api/lists/getbytitle('" + listName + "')/items";
    this.httpClientService.httpPost(siteUrl, item, this.formDigestDetail.FormDigestValue).subscribe(() => {
      this.spinnerService.hide();
      this.toasterService.pop("success", "Course Details", "Course Details Added Successfully");
      this.formDataClear();
      this.router.navigate(['/onboarding/course-detail']);
    }, error => {
      this.spinnerService.hide();
      this.toasterService.pop("error", "Course Details", "Error Occurred While Adding Course Details");
      console.log(error);
    });
  }

  public updateCourseDetail() {
    let listName = "OnboardingCourseDetail";
    var itemType = this.getItemTypeForListName(listName);
    var item = {
      "__metadata": { "type": itemType },
      "Title": this.courseForm.get('title').value,
      "Code": this.courseForm.get('code').value,
      "Reference": this.courseForm.get('url').value,
      "Description": this.courseForm.get('description').value,
      "CourseType": this.courseForm.get('courseType').value,
      "DocumentType": this.courseForm.get('docType').value
    };

    this.spinnerService.show();
    var siteUrl = this.baseUrl + "_api/lists/getbytitle('" + listName + "')/items(" + this.courseId + ")";
    this.httpClientService.httpMerge(siteUrl, item, this.formDigestDetail.FormDigestValue).subscribe((response: Response) => {
      this.spinnerService.hide();
      this.toasterService.pop("success", "Course Details", "Course Details Updated Successfully");
      this.formDataClear();
      this.router.navigate(['/onboarding/course-detail']);
    }, error => {
      this.spinnerService.hide();
      this.toasterService.pop("error", "Course Details", "Error Occurred While Updating Course Details");
      console.log(error);
    });
  }

  public getItemTypeForListName(name) {
    return "SP.Data." + name.charAt(0).toUpperCase() + name.slice(1) + "ListItem";
  }

  private formDataClear() {
    this.courseForm.setValue({
      title: "",
      code: "",
      url: "",
      description: "",
      docType: "",
      courseType: ""
    });
    this.submitted = false;
  }
}