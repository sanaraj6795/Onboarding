import { Component, OnInit, Optional, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '@angular/material';
import { PlanDetails } from 'src/app/providers/model/planDetails';
import { ViewPlanProofComponent } from '../associate-plan/view-plan-proof/view-plan-proof.component';
import { CourseDetailModelComponent } from '../associate-plan/course-detail-model/course-detail-model.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AssociatePlanService } from 'src/app/providers/service/onboarding/associatePlan.service';

@Component({
    selector: 'app-view-current-user-plan-detail',
    templateUrl: './view-user-plan-detail.component.html'
})
export class ViewUserPlanDetailComponent implements OnInit {
    associatePlans: any;
    associateID: any;

    constructor(public dialogRef: MatDialogRef<ViewUserPlanDetailComponent>,
        @Optional() @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog,
        private associatePlanService: AssociatePlanService,
        private spinnerService: Ng4LoadingSpinnerService) {
        this.associateID = data.associateID;
    }

    ngOnInit() {
        this.spinnerService.show();
        this.associatePlanService.getSummary(this.associateID).subscribe(model => {
            if (model && model.value && model.value.length > 0) {
                this.spinnerService.hide();
                this.associatePlans = model.value;
                //this.sortBy('Day', this.associatePlans);
                this.associatePlans.sort((a, b) => a.Day.toString().localeCompare(b.Day.toString()));
                this.associatePlans.sort((a, b) => a.Week.localeCompare(b.Week));
            }
        }, error => {
            this.spinnerService.hide();
            console.log(error);
        });
    }

    onNoClick(): void {
        this.dialogRef.close();
    }

    viewFile(associateplan: PlanDetails): void {
        const dialogRef = this.dialog.open(ViewPlanProofComponent, {
            maxHeight: "710px",
            disableClose: true,
            data: { associateplan: associateplan }
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result != null) {
            }
        });
    }

    showCourseDetails(associateplan: PlanDetails) {
        const dialogRef = this.dialog.open(CourseDetailModelComponent, {
            maxHeight: "700px",
            disableClose: true,
            data: { associateplan: associateplan }
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result != null) {
            }
        });
    }

    private sortBy(field: string, associatePlans: any) {
        associatePlans.sort((a: any, b: any) => {
            if (+a[field] < +b[field]) {
                return -1;
            } else if (+a[field] > +b[field]) {
                return 1;
            } else {
                return 0;
            }
        });
        this.associatePlans = associatePlans;
    }
}