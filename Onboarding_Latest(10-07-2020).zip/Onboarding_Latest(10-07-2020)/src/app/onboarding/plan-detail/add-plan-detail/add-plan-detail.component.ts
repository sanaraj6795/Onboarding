import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { Observable, forkJoin } from 'rxjs';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';
import { GroupViewComponent } from '../../course-group/course-detail-view/course-detail-view.component';
import { AddCourseDialogComponent } from '../../course-group/search-course/search-course.component';
import { IUserDetail } from 'src/app/providers/model/userDetail';
import { IRole } from 'src/app/providers/model/role';
import { ICourseDetail } from 'src/app/providers/model/courseDetail';
import { IGroupCourse } from 'src/app/providers/model/groupCourse';
import { UserGroupNewService } from 'src/app/providers/service/onboarding/group-course/userGroup.service';
import { CourseGroupService } from 'src/app/providers/service/onboarding/course-group.service';
import * as moment from 'moment';
import { CourseDetailsService } from 'src/app/providers/service/onboarding/course-details.service';
import { environment } from 'src/environments/environment.prod';
import { HttpClientService } from 'src/app/providers/service/http-client.service';

@Component({
  selector: 'app-group-course',
  templateUrl: './add-plan-detail.component.html',
  styleUrls: ['./add-plan-detail.component.scss']
})
export class AddPlanDetailsComponent implements OnInit {
  courseForm1: FormGroup;
  associateId: string;
  associateIdCount: number = 0;
  associateIdList: Array<number> = [];
  isGenerateClicked: boolean;
  isGenerateDisabled: boolean;
  role: string;
  courseDetail: ICourseDetail[];
  groupCourse: IGroupCourse[] = [];
  groupCourseCount: number = 0;
  id: any;
  startDate: Date;
  incrementDate: Date;
  roleOptions: IRole;
  isAddCourseDisabled: boolean = true;
  userDetails: IUserDetail[] = [];
  userDetailsError: boolean;
  userIdError: boolean;
  formDigestDetail: any;
  courseType: Array<string> = ['Common', 'Technology', 'Insurance', 'RLG'];
  holiday = [];
  dayDropdownValue: number;
  courseForm: FormGroup;
  submitted = false;
  onboardingGroupsIds: any;

  baseUrl = environment.apiBaseUrl;
  baseAppUrl = environment.appWebUrl;
  emailFrom = environment.emailFrom;
  onboardingListAccess = environment.onboardingListAccessGroupName;
  onboardingAppAccess = environment.onboardingAppAccessGroupName;

  constructor(private userGroupService: UserGroupNewService, public dialog: MatDialog, private formBuilder: FormBuilder,
    private coursesService: CourseGroupService,
    private router: Router,
    private toasterService: ToasterService,
    private httpClientService: HttpClientService,
    private spinnerService: Ng4LoadingSpinnerService,
    private courseDetailService: CourseDetailsService) { }

  ngOnInit() {
    this.courseDetailService.getCourseType().subscribe(model => {
      this.courseType = model.value;
    });

    this.getFormDigest();
    this.createForm();
    this.getRoleOptions();
    this.getHolidayDate();
    this.getAppandListGroupIds();
  }

  createForm() {
    this.courseForm = this.formBuilder.group({
      associateId: [''],
      role: ['', Validators.required],
      startDate: ['', Validators.required]
    });
  }

  private getFormDigest() {
    this.spinnerService.show();
    this.httpClientService.getFormDigest().subscribe((response: Response) => {
      this.formDigestDetail = response;
      this.spinnerService.hide();
    }, error => {
      this.spinnerService.hide();
      console.log(error);
    });
  }

  onSubmit() {
    this.submitted = true;
    if (this.courseForm.invalid) {
      return;
    }
  }

  onKeyUp() {
    this.userIdError = false;
  }

  get f() { return this.courseForm.controls; }

  addAssociateId() {
    this.userIdError = false;
    this.associateId = this.courseForm.get('associateId').value;
    if (this.associateId === "") {
      this.userIdError = true;
      return;
    }

    const isAssociateId = this.userDetails.filter(x => x.AssociateId === this.associateId);

    if (isAssociateId.length > 0) {
      this.toasterService.pop("info", "User Info", "Associate Id Adready Added");
      return;
    }

    this.userGroupService.getUserDetail(this.associateId).subscribe(model => {
      if (model && model.value) {
        this.userDetails.push(model.value);
        this.userDetailsError = false;
        this.courseForm.controls['associateId'].setValue("");
      } else {
        this.toasterService.pop("info", "User Info", "Invalid User Id");
      }
    });
  }

  deleteAssociateId(data: any) {
    this.userDetailsError = false;
    this.userDetails.splice(this.userDetails.indexOf(data), 1);
  }

  deleteCourseItem(data: any) {
    const removeItem = this.courseDetail.filter(x => x.code == data.code);
    this.courseDetail.splice(this.courseDetail.indexOf(removeItem[0]), 1);
    this.courselist(this.courseDetail);
  }

  generateClicked() {
    this.submitted = true;
    this.userDetailsError = false;
    this.userIdError = false;
    if (this.courseForm.invalid || this.userDetails.length === 0) {
      if (this.userDetails.length === 0) {
        this.userDetailsError = true;
      }
      return;
    } else {
      this.getCourseListDetails();
      if (this.groupCourseCount != 0 && this.startDate != null) {
        this.isGenerateClicked = true;
        this.isGenerateDisabled = true;
        this.isAddCourseDisabled = false;
      }
    }
  }

  clearData() {
    this.clearAll();
    this.courseForm.setValue({
      associateId: "",
      role: "",
      startDate: ""
    });
    this.submitted = false;
    this.userDetailsError = false;
    this.courseDetail = null;
    this.userDetails = [];
  }

  viewCourseGroupDetail(): void {
    if (this.courseForm.get('role').value != "") {
      const dialogRef = this.dialog.open(GroupViewComponent, {
        disableClose: true,
        data: { courseIds: this.courseForm.get('role').value.toString() }
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result != null) {
        }
      });
    } else {
      this.toasterService.pop("error", "Role", "Please Select Role");
    }
  }

  submitOnboardingDetails() {
    this.spinnerService.show();
    let listName = "OnboardingPlanDetail";
    var itemType = this.getItemTypeForListName(listName);
    let summaryListName = "OnboardingPlanSummary";
    var summaryItemType = this.getItemTypeForListName(summaryListName);

    var item = [];
    var summaryItem = [];
    this.userDetails.forEach(x => {
      this.groupCourse.forEach(y => {
        var test = {
          "__metadata": { "type": itemType },
          "AssociateID": x.AssociateId,
          "Week": y.week,
          "Day": y.day.toString(),
          "Date": y.startDate,
          "CourseCode": y.courseCode,
          "CourseTitle": y.title,
          "ReferenceUrl": y.url,
          "DocumentType": y.documentType,
          "CourseType": y.courseType
        }
        item.push(test);
      });

      var summaryData = {
        "__metadata": { "type": summaryItemType },
        "Title": x.AssociateId,
        "OnboardingStatus": "yet to start",
        "StartDate": moment(new Date()).format("DD/MM/YYYY"),
        "CompletionPercentage": "0"
      }
      summaryItem.push(summaryData);
    });

    const calls = [];
    var siteUrlSummary = this.baseUrl + "_api/lists/getbytitle('" + summaryListName + "')/items";
    var siteUrl = this.baseUrl + "_api/lists/getbytitle('" + listName + "')/items";

    summaryItem.forEach((associateSummary) => {
      calls.push(this.httpClientService.httpPost(siteUrlSummary, associateSummary, this.formDigestDetail.FormDigestValue));
    });

    item.forEach((singleItem) => {
      calls.push(this.httpClientService.httpPost(siteUrl, singleItem, this.formDigestDetail.FormDigestValue));
    });

    forkJoin(calls).subscribe(responses => {
      this.spinnerService.hide();
      const raiseOnboardingGroupAccessCalls = this.raiseOnboardingGroupAccess();
      forkJoin(raiseOnboardingGroupAccessCalls).subscribe((response: any) => {
        this.toasterService.pop("success", "Onboarding", "Onboarding Raised Successfully");
        this.spinnerService.hide();
        this.router.navigate(["onboarding/plan-detail-summary"]);
      }, error => {
        this.toasterService.pop("error", "Onboarding", "Error Occurred While Raise Onboarding");
        this.spinnerService.hide();
      });
    });
  }

  public getItemTypeForListName(name) {
    return "SP.Data." + name.charAt(0).toUpperCase() + name.slice(1) + "ListItem";
  }

  private clearAll() {
    this.isGenerateDisabled = false;
    this.isGenerateClicked = false;
    this.groupCourse = [];
    this.isAddCourseDisabled = true;
  }

  private getRoleOptions() {
    this.spinnerService.show();
    this.userGroupService.getRoleOptions().subscribe(options => {
      this.spinnerService.hide();
      this.roleOptions = options.value
    });
  }

  private getHolidayDate() {
    this.spinnerService.show();
    this.userGroupService.getHolidayPlans().subscribe(options => {
      this.spinnerService.hide();
      this.holiday = options.value;
    });
  }

  private getCourseListDetails() {
    this.startDate = this.courseForm.get('startDate').value;
    this.incrementDate = this.startDate;
    if (this.startDate != null) {
      this.spinnerService.show();
      this.coursesService.getCourseDetailsByIds(this.courseForm.get('role').value).subscribe(modal => {
        this.spinnerService.hide();
        this.courseDetail = modal.value;
        this.courselist(this.courseDetail);
      });
    }
  }

  private courselist(courseList: ICourseDetail[]) {
    this.groupCourse = [];
    let i = 1, j = 1;
    this.incrementDate = this.getWeekDays(this.incrementDate);
    this.courseType.forEach(x => {
      courseList.map(y => {
        if (x == y.courseType) {
          let data = {
            day: i,
            week: j.toString(),
            startDate: this.incrementDate.toString(),
            courseType: y.courseType,
            code: y.code,
            title: y.title,
            url: y.url,
            courseCode: y.code,
            documentType: y.documentType,
            isDayChangeDisabled: false
          };

          this.groupCourse.push(data);
          let dt = new Date(this.incrementDate);
          dt.setDate(dt.getDate() + 1);
          this.incrementDate = this.getWeekDays(dt);
          if (i % 5 == 0) {
            j++;
            i = 0;
          }
          i++;
        }
      })
    });
    this.groupCourseCount = this.groupCourse.length;
  }

  getWeekDays(newIncrementDate: Date) {
    let dt = new Date(newIncrementDate);
    this.holiday.forEach(dt1 => {
      let newdt = new Date(dt1);
      if (dt.toDateString() == newdt.toDateString()) {
        dt.setDate(dt.getDate() + 1);
      }
    });
    let newDateValue = this.getWeekends(dt);
    return newDateValue;
  }

  getWeekends(newDate: Date) {
    let dt = new Date(newDate);
    if (dt.getDay() == 6) {
      dt.setDate(dt.getDate() + 2);
    } else if (dt.getDay() == 0) {
      dt.setDate(dt.getDate() + 1);
    }
    return dt;
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(AddCourseDialogComponent, {
      width: '70%',
      maxHeight: "700px",
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result != null) {
        result.forEach(e => {
          if (!this.groupCourse.some(x => x.title == e.title)) {
            let data;
            let indexValue = 0;
            this.groupCourse.forEach(x => {
              if (x.courseType == e.courseType && this.groupCourse.indexOf(x) > indexValue) {
                indexValue = this.groupCourse.indexOf(x);
              }
            });
            let singleCourse = this.groupCourse[indexValue];
            data = {
              day: singleCourse.day,
              week: singleCourse.week,
              startDate: singleCourse.startDate,
              courseType: e.courseType,
              code: e.code,
              title: e.title,
              url: e.url,
              courseCode: e.code,
              documentType: e.documentType,
              isDayChangeDisabled: false
            }
            this.courseDetail.push(e);
            this.groupCourse.splice(indexValue + 1, 0, data);
          }
        });
        this.isGenerateClicked = true;
        this.isGenerateDisabled = true;
      }
    });
  }

  private onDayChange(newday, groupCourseData: IGroupCourse) {
    let index = this.groupCourse.indexOf(groupCourseData);
    let similarDaysCount = this.groupCourse.filter(x => x.day == groupCourseData.day && x.week == groupCourseData.week);
    let existingDay = this.groupCourse.find(x => x.day == newday && x.week == groupCourseData.week);
    let existingDayIndex = this.groupCourse.indexOf(existingDay);
    if (newday > groupCourseData.day && similarDaysCount.length < 2) {
      groupCourseData.isDayChangeDisabled = true;
      this.toasterService.pop("error", "Onboarding Courses", "There Should be atleast one course for each day");
    }
    if (newday < groupCourseData.day) {
      let newDay = this.groupCourse[existingDayIndex].day;
      let newWeek = Number(this.groupCourse[existingDayIndex].week);
      let newIncrementDate = this.groupCourse[existingDayIndex].startDate;
      this.groupCourse.forEach(x => {
        if (this.groupCourse.indexOf(x) >= index) {
          x.day = newDay;
          x.week = newWeek.toString();
          x.startDate = newIncrementDate;
          if (newDay % 5 == 0) {
            newWeek++;
            newDay = 0;
          }
          newDay++;
          let newDate = new Date(newIncrementDate);
          newDate.setDate(newDate.getDate() + 1);
          newIncrementDate = this.getWeekDays(newDate).toString();
        }
      });
      this.getSimilarDayEnabled(this.groupCourse[existingDayIndex]);
    }
    else if (newday > groupCourseData.day && similarDaysCount.length >= 2) {
      if (this.groupCourse.find(x => x.day == newday && x.week == groupCourseData.week)) {
        this.groupCourse[index].day = this.groupCourse[existingDayIndex].day;
        this.groupCourse[index].week = Number(this.groupCourse[existingDayIndex].week).toString();
        this.groupCourse[index].startDate = this.groupCourse[existingDayIndex].startDate;
        this.getSimilarDayEnabled(this.groupCourse[existingDayIndex]);
      }
      else {
        let dt = new Date(this.groupCourse[index].startDate);
        dt.setDate(dt.getDate() + 1);
        this.groupCourse[index].day = Number(newday);
        this.groupCourse[index].startDate = this.getWeekDays(dt).toString();
        this.getSimilarDayEnabled(this.groupCourse[index]);
      }
    }
    this.groupCourse.sort((a, b) => a.day.toString().localeCompare(b.day.toString()));
    this.groupCourse.sort((a, b) => a.week.localeCompare(b.week));
  }

  private getSimilarDayEnabled(similarDaysCount: IGroupCourse) {
    let samedays = this.groupCourse.filter(x => x.day == similarDaysCount.day && x.week == similarDaysCount.week);
    samedays.forEach(x => {
      x.isDayChangeDisabled = false;
    })
  }

  private getAppandListGroupIds() {
    this.spinnerService.show();
    var apiURLOnboardingAppAccess = this.baseUrl + "_api/web/sitegroups/?$filter=Title eq '" + this.onboardingAppAccess + "'&$top=1";
    var apiURLOnboardingListAccess = this.baseUrl + "_api/web/sitegroups/?$filter=Title eq '" + this.onboardingListAccess + "'&$top=1";

    const apiURLOnboardingAppAccessCall = this.httpClientService.httpGet(apiURLOnboardingAppAccess);
    const apiURLOnboardingListAccessCall = this.httpClientService.httpGet(apiURLOnboardingListAccess);

    forkJoin(apiURLOnboardingAppAccessCall, apiURLOnboardingListAccessCall).subscribe((response: any) => {
      console.log(response);
      if (response && response.length > 0) {
        this.onboardingGroupsIds = { OnboardingAppAccess: response[0].value[0].Id, OnboardingListAccess: response[1].value[0].Id };
      }
      this.spinnerService.hide();
    }, error => {
      console.log(error);
      this.toasterService.pop("error", "Onboarding", "Error Occurred While getting User Groups");
      this.spinnerService.hide();
    });
  }

  private raiseOnboardingGroupAccess() {
    const raiseOnboardingGroupAccessCalls = [];
    this.spinnerService.show();
    this.userDetails.forEach((singleItem) => {

      const associateName = singleItem.DisplayName.replace("(Cognizant)", "");
      const template = this.getTemplate().replace("[AssociateName]", associateName).replace("[AppUrl]", this.baseAppUrl);

      const userEmailInput = {
        'properties': {
          '__metadata': {
            'type': 'SP.Utilities.EmailProperties'
          },
          'From': this.emailFrom,
          'To': {
            'results': [singleItem.Email]
          },
          'Body': template,
          'Subject': "Welcome to RLG"
        }
      };

      const userAccessInput = {
        "__metadata": {
          "type": "SP.User"
        },
        "LoginName": "i:0#.f|membership|" + singleItem.AssociateId + "@cognizant.com"
      };

      var siteUrlEmail = this.baseUrl + "_api/SP.Utilities.Utility.SendEmail";
      raiseOnboardingGroupAccessCalls.push(this.httpClientService.httpPost(siteUrlEmail, userEmailInput, this.formDigestDetail.FormDigestValue));

      const siteUrlOnboardingAppAccess = this.baseUrl + "_api/web/sitegroups/GetById(" + this.onboardingGroupsIds.OnboardingAppAccess + ")/users";
      raiseOnboardingGroupAccessCalls.push(this.httpClientService.httpPost(siteUrlOnboardingAppAccess, userAccessInput, this.formDigestDetail.FormDigestValue));

      const siteUrlOnboardingListAccess = this.baseUrl + "_api/web/sitegroups/GetById(" + this.onboardingGroupsIds.OnboardingListAccess + ")/users";
      raiseOnboardingGroupAccessCalls.push(this.httpClientService.httpPost(siteUrlOnboardingListAccess, userAccessInput, this.formDigestDetail.FormDigestValue));
    });

    return raiseOnboardingGroupAccessCalls;
  }

  private getTemplate() {
    return `<!DOCTYPE html
    PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="x-apple-disable-message-reformatting">

    <title></title>

    <style type="text/css" rel="stylesheet" media="all">
        body {
            width: 100% !important;
            height: 100%;
            margin: 0;
            -webkit-text-size-adjust: none;
        }

        body {
            font-family: "Nunito Sans", Helvetica, Arial, sans-serif;
        }

        body {
            background-color: #F4F4F7;
            color: #51545E;
        }

        .bodyclass {
            width: 100% !important;
            height: 100%;
            -webkit-text-size-adjust: none;
            font-family: "Nunito Sans&quot;, Helvetica, Arial, sans-serif";
            background-color: #F4F4F7;
            color: #51545E;
            margin: 0;
        }

        .preheader {
            display: none !important;
            visibility: hidden;
            mso-hide: all;
            font-size: 1px;
            line-height: 1px;
            max-height: 0;
            max-width: 0;
            opacity: 0;
            overflow: hidden;
        }

        p {
            color: #51545E;
        }

        p.sub {
            color: #6B6E76;
        }

        .email-wrapper {
            width: 100%;
            -premailer-width: 100%;
            -premailer-cellpadding: 0;
            -premailer-cellspacing: 0;
            background-color: #F4F4F7;
            margin: 0;
            padding: 0;
        }

        .p-clas {
            font-size: 16px;
            line-height: 1.625;
            color: #51545E;
            margin: 2.4em 0 0.1875em;
        }

        .p-clas-1 {
            font-size: 16px;
            line-height: 1.625;
            color: #51545E;
            margin: 0 0 0.1875em;
        }

        .h1-clas-1 {
            margin-top: 0;
            color: #333333;
            font-size: 22px;
            font-weight: bold;
            text-align: left;
        }

        .email-content-td {
            word-break: break-word;
            font-family: "Nunito Sans,Helvetica,Arial,sans-serif";
            font-size: 16px;
        }

        .button-green {
            background-color: #e2542f;
            border-top: 10px solid #e2542f;
            border-right: 18px solid #e2542f;
            border-bottom: 10px solid #e2542f;
            border-left: 18px solid #e2542f;
            margin-top: 15px !important;
        }

        .email-content {
            width: 100%;
            -premailer-width: 100%;
            -premailer-cellpadding: 0;
            -premailer-cellspacing: 0;
            margin: 0;
            padding: 0;
        }

        @media only screen and (max-width: 600px) {

            .email-body_inner,
            .email-footer {
                width: 100% !important;
            }
        }

        @media (prefers-color-scheme: dark) {

            body,
            .email-body,
            .email-body_inner,
            .email-content,
            .email-wrapper,
            .email-masthead,
            .email-footer {
                background-color: #333333 !important;
                color: #FFF !important;
            }

            p,
            ul,
            ol,
            blockquote,
            h1,
            h2,
            h3 {
                color: #FFF !important;
            }

            .attributes_content,
            .discount {
                background-color: #222 !important;
            }

            .email-masthead_name {
                text-shadow: none !important;
            }
        }

        .content-cell {
            word-break: break-word;
            font-family: &quot;
            Nunito Sans&quot;
            ,
            Helvetica,
            Arial,
            sans-serif;
            font-size: 16px;
            padding: 35px;
        }

        .email-masthead_logo {
            width: 94px;
        }

        .email-masthead_name {
            font-size: 20px;
            font-weight: bold;
            color: #e2542f !important;
            text-decoration: none;
        }

        .email-body {
            word-break: break-word;
            margin: 0;
            padding: 0;
            font-family: &quot;
            Nunito Sans&quot;
            ,
            Helvetica,
            Arial,
            sans-serif;
            font-size: 16px;
            width: 100%;
            -premailer-width: 100%;
            -premailer-cellpadding: 0;
            -premailer-cellspacing: 0;
            background-color: #FFFFFF;
        }

        .email-body_inner {
            width: 570px;
            -premailer-width: 570px;
            -premailer-cellpadding: 0;
            -premailer-cellspacing: 0;
            background-color: #FFFFFF;
            margin: 0 auto;
            padding: 0;
        }

        .email-masthead {
            background-color: #421853;
            word-break: break-word;
            font-family: &quot;
            Nunito Sans&quot;
            ,
            Helvetica,
            Arial,
            sans-serif;
            font-size: 16px;
            text-align: center;
            padding: 25px 0;
        }

        .button {
        background-color: #e2542f;
        border-top: 10px solid #e2542f;
        border-right: 18px solid #e2542f;
        border-bottom: 10px solid #e2542f;
        border-left: 18px solid #e2542f;
        display: inline-block;
        color: #FFF;
        text-decoration: none;
        border-radius: 3px;
        box-shadow: 0 2px 3px rgba(0, 0, 0, 0.16);
        -webkit-text-size-adjust: none;
        box-sizing: border-box;
    }

    @media only screen and (max-width: 500px) {
        .button {
            width: 100% !important;
            text-align: center !important;
        }
    }
    a {
            color: #3869D4;
        }

        a img {
            border: none;
        }
        .button {
            background-color: #3869D4;
            border-top: 10px solid #3869D4;
            border-right: 18px solid #3869D4;
            border-bottom: 10px solid #3869D4;
            border-left: 18px solid #3869D4;
            display: inline-block;
            color: #FFF;
            text-decoration: none;
            border-radius: 3px;
            box-shadow: 0 2px 3px rgba(0, 0, 0, 0.16);
            -webkit-text-size-adjust: none;
            box-sizing: border-box;
        }    
    </style>
</head>

<body class="bodyclass" bgcolor="#F4F4F7">
    <span class="preheader">This is example text for the preheader set via the YAML front-matter for each email.</span>
    <table class="email-wrapper" width="100%" cellpadding="0" cellspacing="0" role="presentation" bgcolor="#F4F4F7">
        <tr>
            <td class="email-content-td" align="center">
                <table class="email-content" width="100%" cellpadding="0" cellspacing="0" role="presentation">
                    <tr>
                        <td class="email-masthead" align="center">
                            <span class="email-masthead_name">
                                Welcome to RLG
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <td class="email-body" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
                            <table class="email-body_inner" align="center" width="570" cellpadding="0" cellspacing="0"
                                role="presentation" bgcolor="#FFFFFF">
                                <tr>
                                    <td class="content-cell">
                                        <div class="f-fallback">
                                            <hr>
                                            <br>
                                            <h1 class="h1-clas-1" align="left">Dear [AssociateName]</h1>
                                            <p class="p-clas">
                                                Please use below link to access RLG Onboarding Application.</p>
                                                <br>
                                                <a href="[AppUrl]" class="f-fallback button button-green" target="_blank" style="margin-top: 15px !important;color: #FFF; border-color: #e2542f; border-style: solid; border-width: 10px 18px; background-color: #e2542f; display: inline-block; text-decoration: none; border-radius: 3px; box-shadow: 0 2px 3px rgba(0, 0, 0, 0.16); -webkit-text-size-adjust: none; box-sizing: border-box;">Click Here</a>

                                            <p class="p-clas">
                                                Note : Do not share access link with anyone and the attached document is
                                                for
                                                your reference.</p>
                                            <p class="p-clas">
                                                Kindly reach out to Kanakaraj, Pitchaimuthu(713237) / MS, Vinodhini (551722) for any issues.</p>

                                            <p class="p-clas">
                                                Thanks,</p>
                                            <p class="p-clas-1">
                                                RLG Onboarding Team.</p>
                                            <hr>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>

</html>`;
  }
}