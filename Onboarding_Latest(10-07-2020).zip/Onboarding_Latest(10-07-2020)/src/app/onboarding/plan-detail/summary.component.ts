import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { UserGroupNewService } from 'src/app/providers/service/onboarding/group-course/userGroup.service';
import { ISummaryPlanDetails } from 'src/app/providers/model/summary-plan-details';
import { PageChangedEvent } from 'ngx-bootstrap';
import { PlanDetails } from 'src/app/providers/model/planDetails';
import { ViewUserPlanDetailComponent } from './view-user-plan-detail.component';
import { MatDialog } from '@angular/material';

@Component({
    selector: 'app-summary',
    templateUrl: './summary.component.html',
})
export class PlanSummaryComponent implements OnInit {
    courseForm: FormGroup;
    submitted = false;
    summaryPlanDetails: ISummaryPlanDetails[] = [];
    currentPage: number = 0;
    totalItems: number;
    associatePlans: PlanDetails[];

    constructor(
        private formBuilder: FormBuilder,
        private userGroupService: UserGroupNewService,
        public dialog: MatDialog,
        private spinnerService: Ng4LoadingSpinnerService) { }

    ngOnInit() {
        this.createForm();
        this.getPlanSummaryDetail();
    }

    pageChanged(event: PageChangedEvent): void {
        this.currentPage = event.page - 1;
        this.getPlanSummaryDetail();
    }

    clearData() {
        this.courseForm.setValue({
            associateId: ""
        });
        this.getPlanSummaryDetail();
    }

    createForm() {
        this.courseForm = this.formBuilder.group({
            associateId: ['', Validators.required],
        });
    }

    private getPlanSummaryDetail() {
        this.spinnerService.show();
        const startItem = this.currentPage * 10;
        this.userGroupService.getPlanSummaryDetail(null, startItem).subscribe(response => {
            this.spinnerService.hide();
            this.summaryPlanDetails = response.summaryDetails;
            this.totalItems = response.count;
        });
    }

    get f() { return this.courseForm.controls; }

    getPlanSummaryDetailByAssociateId() {
        this.submitted = true;
        if (this.courseForm.invalid) {
            return;
        }
        const associateId = this.courseForm.get('associateId').value;
        this.spinnerService.show();
        this.userGroupService.getPlanSummaryDetail(associateId, 0).subscribe(response => {
            this.spinnerService.hide();
            this.summaryPlanDetails = response.summaryDetails;
            this.totalItems = response.count;
        });
    }

    getPlanDetailsForCurrentUser(associateID: string) {
        const dialogRef = this.dialog.open(ViewUserPlanDetailComponent, {
            width: '70%',
            maxHeight: "700px",
            disableClose: true,
            data: { associateID: associateID }
        });
    }

    private sortBy(field: string, associatePlans: any) {
        associatePlans.sort((a: any, b: any) => {
            if (+a[field] < +b[field]) {
                return -1;
            } else if (+a[field] > +b[field]) {
                return 1;
            } else {
                return 0;
            }
        });
        this.associatePlans = associatePlans;
    }
}