import { Component, OnInit, Optional, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { AssociatePlanService } from 'src/app/providers/service/onboarding/associatePlan.service';
import { DomSanitizer } from '@angular/platform-browser';
import { PlanDetails } from 'src/app/providers/model/planDetails';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
    selector: 'app-view-plan-dialog',
    templateUrl: './view-plan-proof.component.html'
})
export class ViewPlanProofComponent implements OnInit {
    associateplanDetail: PlanDetails;
    imageToShowUrl: any;

    constructor(public dialogRef: MatDialogRef<ViewPlanProofComponent>,
        @Optional() @Inject(MAT_DIALOG_DATA) public data: any,
        private associatePlanService: AssociatePlanService,
        private spinnerService: Ng4LoadingSpinnerService,
        private sanitizer: DomSanitizer) {
        this.associateplanDetail = data.associateplan;
    }

    ngOnInit() {
        this.spinnerService.show();
        this.associatePlanService.viewAttachmentFilesById(this.associateplanDetail.ID)
            .subscribe((resonse: any) => {
                this.spinnerService.hide();
                this.imageToShowUrl = this.sanitize(resonse.value);
            }, (error: any) => {
                this.spinnerService.hide();
                console.log(error);
            });
    }

    onNoClick(): void {
        this.dialogRef.close();
    }

    private sanitize(response: any) {
        const url = 'data:image/jpg;base64, ' + this.arrayBufferToBase64(response);
        return this.sanitizer.bypassSecurityTrustUrl(url);
    }

    private arrayBufferToBase64(buffer) {
        var binary = '';
        var bytes = new Uint8Array(buffer);
        var len = bytes.byteLength;
        for (var i = 0; i < len; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return window.btoa(binary);
    }
}
