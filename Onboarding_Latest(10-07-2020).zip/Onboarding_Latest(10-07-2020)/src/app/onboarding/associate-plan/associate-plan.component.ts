import { Component, OnInit, ElementRef } from '@angular/core';
import { PlanDetails } from 'src/app/providers/model/planDetails';
import { AssociatePlanService } from 'src/app/providers/service/onboarding/associatePlan.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ToasterService } from 'angular2-toaster';
import * as moment from 'moment';
import { BsModalService, BsModalRef } from 'ngx-bootstrap';
import { CourseDetailModelComponent } from './course-detail-model/course-detail-model.component';
import { ViewPlanProofComponent } from './view-plan-proof/view-plan-proof.component';
import { MatDialog } from '@angular/material';
import { environment } from 'src/environments/environment.prod';
import { HttpClientService } from 'src/app/providers/service/http-client.service';
import { forkJoin } from 'rxjs';
declare var $: any;

@Component({
  selector: 'rlg-onboarding-associate-plan',
  templateUrl: './associate-plan.component.html',
  styleUrls: ['./associate-plan.component.scss']
})

export class AssociatePlanComponent implements OnInit {
  associatePlans: PlanDetails[];
  currentFile: File;
  associateID: string;
  courseCode: string;
  formDigestDetail: any;
  bsModalRef: BsModalRef;
  associateplanNew: PlanDetails;
  associateplanNew1: PlanDetails;

  baseUrl = environment.apiBaseUrl;

  constructor(private associatePlanService: AssociatePlanService,
    private httpClientService: HttpClientService,
    private toasterService: ToasterService,
    private spinnerService: Ng4LoadingSpinnerService,
    private elem: ElementRef,
    private modalService: BsModalService,
    public dialog: MatDialog) { }

  ngOnInit() {
    this.associateplanNew = new PlanDetails("568182", "1", "1", new Date(), "ASDAS", "SDFSDF", "fILE", "https://insurance.cognizant.com/uksbu/RLG/KT%20Repository/RLG%20Induction%20Materials/Induction%20Plan/Royal%20London%20Group_KYC.pptx", "SDFDS", new Date(), "dfd", true, 1);
    this.associateplanNew1 = new PlanDetails("568182", "1", "1", new Date(), "ASDAS", "SDFSDF", "fILE", "fghfghfgh", "SDFDS", new Date(), "dfd", true, 1);
    this.getFormDigest();
    this.getPlanDetails(false);
  }

  private getFormDigest() {
    this.spinnerService.show();
    this.httpClientService.getFormDigest().subscribe((response: Response) => {
      this.formDigestDetail = response;
      this.spinnerService.hide();
    }, error => {
      this.spinnerService.hide();
      console.log(error);
    });
  }

  getCompletionDate(completionDate: any): any {
    const isValidCompletionDate = moment(completionDate).isValid();
    if (isValidCompletionDate) {
      return moment(completionDate).format('dd-MM-yyyy');
    }
    return null;
  }

  showCourseDetails(associateplan: PlanDetails) {
    const dialogRef = this.dialog.open(CourseDetailModelComponent, {
      maxHeight: "700px",
      disableClose: true,
      data: { associateplan: associateplan }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result != null) {
      }
    });
  }

  viewFile(associateplan: PlanDetails): void {
    const dialogRef = this.dialog.open(ViewPlanProofComponent, {
      maxHeight: "710px",
      disableClose: true,
      data: { associateplan: associateplan }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result != null) {
      }
    });
  }

  private getPlanDetails(isPlanSummary: boolean) {
    var numberPattern = /\d+/g;
    this.spinnerService.show();
    this.associatePlanService.getUserInfo().subscribe((response: any) => {
      const object = response.UserProfileProperties
        .reduce((obj, item) => Object.assign(obj, { [item.Key]: item.Value }), {});
        if(!object.Alias){
          object.Alias=(object.UserName).match(numberPattern)[0];
        }
      this.associatePlanService.getSummary(object.Alias).subscribe(model => {
        if (model && model.value && model.value.length > 0) {
          this.spinnerService.hide();
          this.associatePlans = model.value;
          //this.sortBy('Day', this.associatePlans);
          if (this.associatePlans.length > 0) {
            this.associatePlans.sort((a, b) => a.Day.toString().localeCompare(b.Day.toString()));
            this.associatePlans.sort((a, b) => a.Week.localeCompare(b.Week));
          }

          if (isPlanSummary) {
            this.updatePlanSummary(object.Alias);
          }
        }
      });
    }, error => {
      this.spinnerService.hide();
      console.log(error);
    });
  };

  onFileSelected(fileId: any, associateplan: PlanDetails) {
    let filesList = this.elem.nativeElement.querySelector("#file" + fileId).files;
    this.currentFile = null;
    if (filesList.length > 0) {
      this.currentFile = filesList.item(0);
      associateplan.FilePath = this.currentFile.name;
    }
  }

  uploadFileToCourse(fileId, associateplan: PlanDetails) {
    let files = this.elem.nativeElement.querySelector("#" + fileId)

    if (files === 'undefined' || files === null || files === "" || files.files.length == 0) {
      this.toasterService.pop("error", "Plan Details", "Please Select file");
      return;
    }

    let filesList = files.files;
    this.currentFile = filesList.item(0);

    if (this.currentFile.type != "image/jpeg" && this.currentFile.type != "image/png") {
      this.toasterService.pop("error", "Plan Details", "Only JPEG/PNG files are allowed to upload");
      return;
    }
    if (this.currentFile.size > 2000000) {
      this.toasterService.pop("error", "Plan Details", "Plesae upload 2MB Image");
      return;
    }

    this.associatePlanService.getAttachmentFilesCourseById(associateplan.ID).subscribe((resonse: any) => {
      if (resonse && resonse.value && resonse.value.isFile) {
        this.deleteFile(associateplan.ID, resonse.value.FileName);
      } else {
        this.uploadFile(associateplan.ID, this.currentFile.name);
        //this.uploadFileSP(associateplan.ID, this.currentFile.name, this.currentFile);
      }
    }, (error: any) => {
      console.log(error);
    });
  }

  updateCompletionDate(associateplan: PlanDetails, completionDate: Date) {

    if (completionDate === null) {
      this.toasterService.pop("error", "Plan Details", "Please Enter Completion Date");
      return;
    }

    const isValidCompletionDate = moment(completionDate).isValid();
    if (!isValidCompletionDate) {
      this.toasterService.pop("error", "Plan Details", "Please Enter Valid Completion Date");
      return;
    }

    associateplan.CompletionDate = completionDate;
    this.spinnerService.show();
    this.associatePlanService.uploadDate({ id: associateplan.ID, completionDate: associateplan.CompletionDate }, this.formDigestDetail.FormDigestValue)
      .subscribe(() => {
        this.spinnerService.hide();
        this.toasterService.pop("success", "CompletionDate Success", "Successfully Updated CompletionDate");
        this.getPlanDetails(true);
      }, error => {
        this.spinnerService.hide();
        this.toasterService.pop("success", "CompletionDate Success", "Successfully Updated CompletionDate");
        console.log(error);
      });
  }

  private deleteFile(id: number, fileName: string) {
    this.spinnerService.show();
    this.associatePlanService.deleteFile(id, fileName, this.formDigestDetail.FormDigestValue).subscribe(() => {
      this.spinnerService.hide();
      this.uploadFileSP(id, this.currentFile.name, this.currentFile);
    }, error => {
      this.spinnerService.hide();
      this.toasterService.pop("error", "Course Details", "Error Occurred While Adding Course Details");
    });
  }

  private uploadFile(id, fileName) {
    var queryUrl = this.baseUrl + "_api/lists/getbytitle('OnboardingPlanDetail')/items(" + id + ")";

    var itemType = this.getItemTypeForListName('OnboardingPlanDetail');
    var item = {
      "__metadata": { "type": itemType },
      "FileName": fileName
    };

    this.httpClientService.httpMerge(queryUrl, item, this.formDigestDetail.FormDigestValue).subscribe((response: any) => {
      this.uploadFileSP(id, this.currentFile.name, this.currentFile);
      this.spinnerService.hide();
    }, error => {
      console.log(error);
      this.toasterService.pop("error", "Onboarding", "Error in saving FileName");
      this.spinnerService.hide();
    });
  }

  private uploadFileSP(id, fileName, file) {
    this.spinnerService.show();
    var deferred = $.Deferred();

    this.getFileBuffer(file, this.formDigestDetail.FormDigestValue, this.spinnerService, this.toasterService, this).then(
      function (buffer, formDigestValue, spinnerService, toasterService, associatePlanComponent) {
        var queryUrl = associatePlanComponent.baseUrl + "_api/web/lists/getbytitle('OnboardingPlanDetail')/items(" + id + ")/AttachmentFiles/add(FileName='" + fileName + "')";

        $.ajax({
          url: queryUrl,
          type: "POST",
          processData: false,
          contentType: "application/json;odata=verbose",
          data: buffer,
          headers: {
            "accept": "application/json;odata=verbose",
            "X-RequestDigest": formDigestValue
          }, success: function (responseNew) {
            spinnerService.hide();
            toasterService.pop("success", "Attachment Success", "File Uploaded Successfully");
            associatePlanComponent.getPlanDetails(true);
          },
          error: function (error) {
            console.log(error);
            spinnerService.hide();
            toasterService.pop("error", "Attachment Failure:", error.status + "," + error.statusText);
          }
        });
      },
      function (err) {
        this.spinnerService.hide();
        deferred.reject(err);
      });

    return deferred.promise();

  }

  private getFileBuffer(file, formDigestValue, spinnerService, toasterService, associatePlanComponent) {
    var deferred = $.Deferred();
    var reader = new FileReader();
    reader.onload = function (e: any) {
      deferred.resolve(e.target.result, formDigestValue, spinnerService, toasterService, associatePlanComponent);
    }
    reader.onerror = function (e: any) {
      deferred.reject(e.target.error);
    }
    reader.readAsArrayBuffer(file);
    return deferred.promise();
  }

  private sortBy(field: string, associatePlans: any) {

    associatePlans.sort((a: any, b: any) => {
      if (+a[field] < +b[field]) {
        return -1;
      } else if (+a[field] > +b[field]) {
        return 1;
      } else {
        return 0;
      }
    });
    this.associatePlans = associatePlans;
  }

  private updatePlanSummary(id: any) {

    const associatePercentage = this.associatePlans.filter(x => x.CompletionDate != null || x.Attachments != false);
    const completionPercentage = associatePercentage.length / this.associatePlans.length * 100;
    const completionPercentageRound = Math.round(completionPercentage);
    this.spinnerService.show();
    this.associatePlanService.updatePlanSummary(id, completionPercentageRound.toString(), this.formDigestDetail.FormDigestValue)
      .subscribe(() => {
        this.spinnerService.hide();
      }, error => {
        this.spinnerService.hide();
        console.log(error);
      });
  }

  public getItemTypeForListName(name) {
    return "SP.Data." + name.charAt(0).toUpperCase() + name.slice(1) + "ListItem";
  }
}