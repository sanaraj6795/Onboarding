import { Component, OnInit, Optional, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
    selector: 'app-view-plan-dialog',
    templateUrl: './course-detail-model.component.html',
    styleUrls: ['./course-detail-model.component.scss']
})
export class CourseDetailModelComponent implements OnInit {
    associatePlan: any;
    constructor(public dialogRef: MatDialogRef<CourseDetailModelComponent>,
        @Optional() @Inject(MAT_DIALOG_DATA) public data: any) {
        this.associatePlan = data.associateplan;
    }

    ngOnInit() {
    }

    onNoClick(): void {
        this.dialogRef.close();
    }

    isReferenceUrl(referenceUrl: string): boolean {
        return referenceUrl.includes('http');
    }
}
