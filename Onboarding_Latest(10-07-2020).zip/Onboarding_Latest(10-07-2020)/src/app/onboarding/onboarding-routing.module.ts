import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AssociatePlanComponent } from './associate-plan/associate-plan.component';
import { DashBoardComponent } from './dashboard/dashboard.component';
import { CourseDetailsListComponent } from './course-group/summary/course-group-list.component';
import { CourseDetailsComponent } from './course-details/add-course/course-details.component';
import { CourseListComponent } from './course-details/summary/course-list.component';
import { AddCourseGroupComponent } from './course-group/add-course-group/add-course-group.component';
import { AddPlanDetailsComponent } from './plan-detail/add-plan-detail/add-plan-detail.component';
import { PlanSummaryComponent } from './plan-detail/summary.component';
import { MigrationComponent } from './migration/migration.component';

const routes: Routes = [
    {
        path: 'onboarding',
        resolve: {
            // onboarding : onboarding
        },
        children: [
            { path: '', component: DashBoardComponent },
            { path: 'dashboard', component: DashBoardComponent },
            { path: 'plan-detail', component: AssociatePlanComponent },
            { path: 'plan-detail-summary', component: PlanSummaryComponent },
            { path: 'course-detail', component: CourseListComponent },
            { path: 'course-detail/add', component: CourseDetailsComponent },
            { path: 'course-detail/edit/:id', component: CourseDetailsComponent },
            { path: 'user-role/add', component: AddCourseGroupComponent },
            { path: 'user-role/edit/:id', component: AddCourseGroupComponent },
            { path: 'user-role-detail', component: CourseDetailsListComponent },
            { path: 'add-plan-detail', component: AddPlanDetailsComponent },
            { path: 'application-permission', component: MigrationComponent }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class OnboardingRoutingModule { }
