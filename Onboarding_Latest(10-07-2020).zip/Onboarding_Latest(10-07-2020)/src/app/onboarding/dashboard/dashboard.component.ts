import { Component, OnInit } from '@angular/core';
import { IDashboard } from 'src/app/providers/model/dashboard';
import { DashboardService } from 'src/app/providers/service/dashboard.service';
import { Label, PluginServiceGlobalRegistrationAndOptions } from 'ng2-charts';
import { ChartDataSets, ChartType, ChartOptions } from 'chart.js';

@Component({
    selector: 'rlg-onboarding-dashboard',
    templateUrl: './dashboard.component.html'
})
export class DashBoardComponent implements OnInit {
    constructor() { }

    ngOnInit(): void {
    }

    // Doughnut Chart
    public doughnutChartData: number[] = [45, 55, 65];
    public doughnutChartLabels: Label[] = ['Download Sales', 'In-Store Sales', 'Mail-Order Sales'];
    public doughnutChartType: string = 'doughnut';
    public doughnutChartColours: any[] = [{
        backgroundColor: ['#16a085', '#00a3d8', '#27579e']
    }];

    public doughnutOptions: any = {
        responsive: true,
        cutoutPercentage: 80,
        legend: {
            display: true,
            position: 'right',
            align: "middle"
        }
    };

    public doughnutChartPlugins: any[] = [{
        afterDraw(chart) {
            const ctx = chart.ctx;
            var txt1 = '';
            var txt2 = '';

            try {
                var check = chart.active ? chart.tooltip._active[0]._datasetIndex : "None";
                if (check !== "None") {
                    txt1 = chart.tooltip._data.labels[chart.tooltip._active[0]._index];
                    txt2 = chart.tooltip._data.datasets[0].data[chart.tooltip._active[0]._index];
                } else {
                    txt1 = chart.tooltip._data.labels[0];
                    txt2 = chart.tooltip._data.datasets[0].data[0];
                }
            }
            catch (err) {
                txt1 = chart.tooltip._data.labels[0]
                txt2 = chart.tooltip._data.datasets[0].data[0];
            }
            //Get options from the center object in options
            const sidePadding = 60;
            const sidePaddingCalculated = (sidePadding / 100) * (chart.innerRadius * 2)

            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            const centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
            const centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);

            //Get the width of the string and also the width of the element minus 10 to give it 5px side padding

            const stringWidth = ctx.measureText(txt1).width;
            const elementWidth = (chart.innerRadius * 2) - sidePaddingCalculated;

            // Find out how much the font can grow in width.
            const widthRatio = elementWidth / stringWidth;
            const newFontSize = Math.floor(30 * widthRatio);
            const elementHeight = (chart.innerRadius * 2);

            // Pick a new font size so it will not be larger than the height of label.
            const fontSizeToUse = 30;
            ctx.font = fontSizeToUse + 'px Arial';
            ctx.fillStyle = 'black';

            // Draw text in center
            ctx.fillText(txt2, centerX, centerY - 10);
            var fontSizeToUse1 = 15;
            ctx.font = fontSizeToUse1 + 'px Arial';
            ctx.fillText(txt1, centerX, centerY + 10);
        }
    }];

    // events
    public doughnutChartClicked(e: any, doughnutChartData: any): void {
    }

    public barChartOptions: ChartOptions = {
        responsive: true,
        cutoutPercentage: 90,
        // We use these empty structures as placeholders for dynamic theming.
        scales: { xAxes: [{}], yAxes: [{}] },
        legend: {
            display: true,
            position: 'right'
        },
        plugins: {
            datalabels: {
                anchor: 'end',
                align: 'end',
            }
        }
    };
    public barChartLabels: Label[] = ['2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019'];
    public barChartType: ChartType = 'bar';
    public barChartLegend = true;
    // public barChartPlugins = [pluginDataLabels];

    public barChartData: ChartDataSets[] = [
        {
            data: [65, 59, 80, 81, 56, 55, 40, 50, 81, 82, 57, 56],
            label: 'Series A'
        }
    ];

    // events
    public chartClicked({ event, active }: { event: MouseEvent, active: {}[] }): void {
        console.log(event, active);
    }

    public chartHovered({ event, active }: { event: MouseEvent, active: {}[] }): void {
        console.log(event, active);
    }

    public randomize(): void {
        // Only Change 3 values
        const data = [
            Math.round(Math.random() * 100),
            59,
            80,
            (Math.random() * 100),
            56,
            (Math.random() * 100),
            40];
        this.barChartData[0].data = data;
    }
}