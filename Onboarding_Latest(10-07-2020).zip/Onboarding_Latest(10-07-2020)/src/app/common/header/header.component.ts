import { Component, OnInit } from '@angular/core';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { environment } from 'src/environments/environment.prod';
import { HttpClientService } from 'src/app/providers/service/http-client.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  status: string;
  userDetail: any;
  onboardingRouteDetails: any[] = [];
  resourceMasterRouteDetails: any[] = [];

  routePath = [
    { "path": "onboarding/course-detail", "displayName": "Course Details", "category": "Onboarding", "isOther": false },
    { "path": "onboarding/user-role-detail", "displayName": "User Group Details", "category": "Onboarding", "isOther": false },
    { "path": "onboarding/add-plan-detail", "displayName": "Raise Onboarding", "category": "Onboarding", "isOther": false },
    { "path": "onboarding/plan-detail", "displayName": "Plan Detail", "category": "Onboarding", "isOther": true },
    { "path": "onboarding/plan-detail-summary", "displayName": "Plan Detail Summary", "category": "Onboarding", "isOther": false },
    { "path": "onboarding/application-permission", "displayName": "Application Permission", "category": "Onboarding", "isOther": false },
    { "path": "resourcemaster/dashboard", "displayName": "Resource Master", "category": "ResourceMaster", "isOther": false }
  ];

  baseUrl = environment.apiBaseUrl;
  onboardingAdmin = environment.onboardingAdminGroupName;
  resourceMasterAdmin = environment.resourceMasterAdminGroupName;

  constructor(private httpClientService: HttpClientService,
    private spinnerService: Ng4LoadingSpinnerService) { }

  ngOnInit(): void {
    this.getUserInfo();
  }

  setStatus = message => {
    this.status = message;
  };

  private getUserInfo() {
    this.spinnerService.show();
    var siteUrl = this.baseUrl + "_api/web/currentuser/?$expand=groups";
    this.httpClientService.httpGet(siteUrl).subscribe((response: any) => {
      this.userDetail = response;
      const userGroup = response.Groups.map(x => x.LoginName);

      const isOnboarding = userGroup.filter(x => x == this.onboardingAdmin);
      if (isOnboarding.length) {
        this.onboardingRouteDetails = this.routePath.filter(route => route.category == "Onboarding");
      } else {
        this.onboardingRouteDetails = this.routePath.filter(route => route.isOther == true && route.category == "Onboarding");
      }

      const isResourceMasterAdmin = userGroup.filter(x => x == this.resourceMasterAdmin);
      if (isResourceMasterAdmin.length) {
        this.resourceMasterRouteDetails = this.routePath.filter(route => route.category == "ResourceMaster");
      } else {
        this.resourceMasterRouteDetails = this.routePath.filter(route => route.isOther == true && route.category == "ResourceMaster");
      }

    }, error => {
      this.spinnerService.hide();
      console.log(error);
    });
  }
}
