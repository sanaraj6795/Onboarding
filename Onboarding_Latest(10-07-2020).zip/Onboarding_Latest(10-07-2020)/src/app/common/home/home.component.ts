import { Component, OnInit } from '@angular/core';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { SkillSetService } from 'src/app/providers/service/skill-set.service';
import { ToasterService } from 'angular2-toaster';
import { SkillSet } from 'src/app/providers/model/skill-set';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment.prod';
import { HttpClientService } from 'src/app/providers/service/http-client.service';

declare var $: any;

@Component({
    selector: 'rlg-pmo-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
    skillForm: FormGroup;
    status: string;
    userInfo: any;
    skillSet: SkillSet;
    skills: string[] = [];
    formDigestDetail: any;
    planSummary: any;
    royalLondonInfo: any;
    userIdPattern=Validators.pattern(/^[0-9]\d*$/);

    baseUrl = environment.apiBaseUrl;

    constructor(private httpClientService: HttpClientService,
        private spinnerService: Ng4LoadingSpinnerService, private skillSetService: SkillSetService,
        private toasterService: ToasterService, private formBuilder: FormBuilder) { }

    ngOnInit() {
        this.createForm();
        this.getFormDigest();
        this.getUserInfo();
    }
    createForm() {
        this.skillForm = this.formBuilder.group({
            newSkill: ['', Validators.required]
        });
    }

    private getFormDigest() {
        this.spinnerService.show();
        this.httpClientService.getFormDigest().subscribe((response: Response) => {
            this.formDigestDetail = response;
            this.spinnerService.hide();
        }, error => {
            this.spinnerService.hide();
            console.log(error);
        });
    }

    getUserInfo() {
        var numberPattern = /\d+/g;
        var siteUrl = this.baseUrl + "_api/SP.UserProfiles.PeopleManager/GetMyProperties";
        this.spinnerService.show();
        this.httpClientService.httpGet(siteUrl).subscribe((response: any) => {
            var object = response.UserProfileProperties
                .reduce((obj, item) => Object.assign(obj, { [item.Key]: item.Value }), {});
            this.userInfo = object;
            if(!this.userInfo.Alias){
                this.userInfo.Alias=(object.UserName).match(numberPattern)[0];;
            }
            this.spinnerService.hide();
            this.getPlanSummaryById(this.userInfo.Alias);
            this.getUserSkills(this.userInfo.Alias);
            this.getUserDetails(this.userInfo.Alias);
        }, error => {
            console.log(error);
            this.spinnerService.hide();
        });
    }

    setStatus = message => {
        this.status = message;
    }

    private getPlanSummaryById(userId: any) {
        this.spinnerService.show();
        var apiURL = this.baseUrl + "_api/lists/getbytitle('OnboardingPlanSummary')/items?$filter=Title eq " + userId;
        this.httpClientService.httpGet(apiURL).subscribe((response: any) => {
            if (response && response.value.length > 0) {
                this.planSummary = {
                    "CompletionPercentage": response.value[0].CompletionPercentage,
                    "OnboardingStatus": response.value[0].OnboardingStatus,
                    "CompletionDate": response.value[0].CompletionDate ? " On " + response.value[0].CompletionDate : null
                };
            }
            this.spinnerService.hide();
        }, error => {
            console.log(error);
            this.spinnerService.hide();
        });
    }

    getUserSkills(userId: string) {
        if (userId != "" && userId != undefined && userId != null) {
            this.spinnerService.show();
            this.skillSetService.getUserById(userId)
                .subscribe(model => {
                    if (model && model.value) {
                        this.skillSet = model.value;
                        this.skills = this.skillSet.skills != null ? this.skillSet.skills.split(',') : [];
                    }
                    this.spinnerService.hide();
                }, error => {
                    console.log(error);
                    this.spinnerService.hide();
                });
        }
    }

    getUserDetails(userId: string) {
        if (userId != "" && userId != undefined && userId != null) {
            this.spinnerService.show();
            this.skillSetService.getUserDetailsById(userId)
                .subscribe(model => {
                    if (model && model.value) {
                        this.royalLondonInfo = model.value;
                    }
                    this.spinnerService.hide();
                }, error => {
                    console.log(error);
                    this.spinnerService.hide();
                });
        }
    }

    addOrUpdateSkill() {
        if (this.skillForm.invalid) {
            return false;
        }

        var item: any;
        const addSkill = this.skillForm.get('newSkill').value;

        let listName = "OnboardingSkillSet";
        var itemType = this.getItemTypeForListName(listName);

        if (this.skillSet == undefined || this.skillSet == null) {
            this.skills.push(addSkill);
            item = {
                "__metadata": { "type": itemType },
                "AssociateID": this.userInfo.Alias,
                "SkillSet": this.skills.toString()
            };
            var siteUrl = this.baseUrl + "_api/lists/getbytitle('" + listName + "')/items";

            this.spinnerService.show();
            this.httpClientService.httpPost(siteUrl, item, this.formDigestDetail.FormDigestValue).subscribe(() => {
                this.spinnerService.hide();
                this.getUserSkills(this.userInfo.Alias);
                this.toasterService.pop("success", "Skill Set", "Skills Updated Successfully");
                this.skillForm.setValue({
                    newSkill: ""
                });

            }, error => {
                this.spinnerService.hide();
                this.toasterService.pop("error", "Skill Set", "Error Occurred While Updating Skills");
                console.log(error);
            });

        }

        else {
            this.skills.push(addSkill);
            item = {
                "__metadata": { "type": itemType },
                "SkillSet": this.skills.toString()
            };
            var siteUrl = this.baseUrl + "_api/lists/getbytitle('" + listName + "')/items(" + this.skillSet.id + ")";

            this.spinnerService.show();
            this.httpClientService.httpMerge(siteUrl, item, this.formDigestDetail.FormDigestValue).subscribe(() => {
                this.spinnerService.hide();
                this.getUserSkills(this.userInfo.Alias);
                this.toasterService.pop("success", "Skill Set", "Skills Updated Successfully");
                this.skillForm.setValue({
                    newSkill: ""
                });

            }, error => {
                this.spinnerService.hide();
                this.toasterService.pop("error", "Skill Set", "Error Occurred While Updating Skills");
                console.log(error);
            });
        }
    }

    deleteSkill(skill) {
        const index: number = this.skills.indexOf(skill);
        if (index !== -1) {
            this.skills.splice(index, 1);
        }
        var item: any;
        let listName = "OnboardingSkillSet";
        var itemType = this.getItemTypeForListName(listName);
        item = {
            "__metadata": { "type": itemType },
            "SkillSet": this.skills.toString()
        };
        var siteUrl = this.baseUrl + "_api/lists/getbytitle('" + listName + "')/items(" + this.skillSet.id + ")";

        this.spinnerService.show();
        this.httpClientService.httpMerge(siteUrl, item, this.formDigestDetail.FormDigestValue).subscribe(() => {
            this.spinnerService.hide();
            this.getUserSkills(this.userInfo.Alias);
            this.toasterService.pop("success", "Skill Set", "Skills Deleted Successfully");
        }, error => {
            this.spinnerService.hide();
            this.toasterService.pop("error", "Skill Set", "Error Occurred While Deleting Skills");
            console.log(error);
        });
    }

    private getItemTypeForListName(name) {
        return "SP.Data." + name.charAt(0).toUpperCase() + name.slice(1) + "ListItem";
    }
}