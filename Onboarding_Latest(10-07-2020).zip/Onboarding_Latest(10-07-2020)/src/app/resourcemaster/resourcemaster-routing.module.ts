import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RMDashboardComponent } from './dashboard/dashboard.component';
import { ManageResourceComponent } from './manage-resource/manage-resource.component';


const routes: Routes = [
    {
        path: 'resourcemaster',
        resolve: {
        },
        children: [
            {path:'dashboard',component:RMDashboardComponent},
            {path:'viewresource',component:ManageResourceComponent}
        ]
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class ResourceMasterRoutingModule { }
