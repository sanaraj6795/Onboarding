import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { DashBoardComponent } from 'src/app/onboarding/dashboard/dashboard.component';
import { ViewEncapsulation } from '@angular/core';
import { AssociateConstantData } from 'src/app/providers/model/associateconstantdata';
import { ResourceDialogData } from 'src/app/providers/model/resourcedialogdata';
import { MainResourceList } from 'src/app/providers/model/MainResourceList';
import { ToasterService } from 'angular2-toaster';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { DatePipe } from '@angular/common';
import { environment } from 'src/environments/environment.prod';
import { HttpClientService } from 'src/app/providers/service/http-client.service';

@Component({
  selector: 'app-manage-resource',
  templateUrl: './manage-resource.component.html',
  styleUrls: ['./manage-resource.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ManageResourceComponent implements OnInit {

  baseUrl = environment.apiBaseUrl;
  associateConstantData: AssociateConstantData;
  associateVariableInfo: MainResourceList;
  formDigestDetail: any;
  isEditMode = false;
  isCreateMode = false;
  listName = "ResourceMasterAssociateDetails";

  constructor(public dialogRef: MatDialogRef<DashBoardComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ResourceDialogData,
    private toasterService: ToasterService,
    private httpClientService: HttpClientService,
    private datePipe: DatePipe,
    private spinnerService: Ng4LoadingSpinnerService) { }

  ngOnInit() {
    this.getFormDigest();
    if (this.data.basicInfo === null && this.data.detailedInfo === null) {
      this.isCreateMode = true;
      this.isEditMode = true;
      this.initializeForm();
    }
    else {
      this.associateVariableInfo = this.data.detailedInfo;
      this.loadAssociateData();
    }
  }

  private getFormDigest() {
    this.spinnerService.show();
    this.httpClientService.getFormDigest().subscribe((response: Response) => {
      this.formDigestDetail = response;
      this.spinnerService.hide();
    }, error => {
      this.spinnerService.hide();
      console.log(error);
    });
  }

  initializeForm() {
    this.associateVariableInfo = {
      CognizantId: 0,
      SkillSets: "",
      Location: "",
      ESAPrjName: "",
      RsrcAllocEndDt: "",
      VIEndDtOnshore: "",
      VIType: "",
      VIExtPosblByndEnddt: false,
      VIHwLngCanExt: "",
      VIExtPosbleFrmUK: false,
      ResourceName: "",
      RateCardRole: "",
      RateCardDayRate: "",
      OnOff2017: "",
      ProjectProgramme: "",
      Portfolio: "",
      OldSOW: "",
      NewSOWEnddate: "",
      NewSOW: "",
      Billable: false,
      RLGAccountYN: false,
      RLGStaffID: "",
      CTSEL: "",
      RLGID: "",
      RLGEmail: "",
      RLGJoinDate: "",
      RLGLeavingDate: "",
      RLGRprtMgr: "",
      AssetNoOnshore: "",
      VMNoOffshore: "",
      Comments: "",
      PrimarySkill: "",
      Status: "",
    }
  }

  onClickCancel() {
    this.dialogRef.close(true);
  }

  onClickEdit() {
    this.isEditMode = true;
  }

  loadAssociateData() {
    this.associateConstantData = {
      Department: this.data.basicInfo.OtherDetails.find(x => x.Key === "Department").Value,
      CtsLineManager: this.data.basicInfo.OtherDetails.find(x => x.Key === "Manager").Value,
      Email: this.data.basicInfo.OtherDetails.find(x => x.Key === "WorkEmail").Value
    }
  }

  public addAssociateDetail() {

    var itemType = this.getItemTypeForListName(this.listName);
    var item = {
      "__metadata": { "type": itemType },
      "CognizantId": this.associateVariableInfo.CognizantId,
      "SkillSets": this.associateVariableInfo.SkillSets,
      "Location": this.associateVariableInfo.Location,
      "ESAPrjName": this.associateVariableInfo.ESAPrjName,
      "RsrcAllocEndDt": this.associateVariableInfo.RsrcAllocEndDt,
      "VIEndDtOnshore": this.associateVariableInfo.VIEndDtOnshore,
      "VIType": this.associateVariableInfo.VIType,
      "VIExtPosblByndEnddt": this.associateVariableInfo.VIExtPosblByndEnddt,
      "VIHwLngCanExt": this.associateVariableInfo.VIHwLngCanExt,
      "VIExtPosbleFrmUK": this.associateVariableInfo.VIExtPosbleFrmUK,
      "ResourceName": this.associateVariableInfo.ResourceName,
      "RateCardRole": this.associateVariableInfo.RateCardRole,
      "RateCardDayRate": this.associateVariableInfo.RateCardDayRate,
      "OnOff2017": this.associateVariableInfo.OnOff2017,
      "ProjectProgramme": this.associateVariableInfo.ProjectProgramme,
      "Portfolio": this.associateVariableInfo.Portfolio,
      "OldSOW": this.associateVariableInfo.OldSOW,
      "NewSOWEnddate": this.associateVariableInfo.NewSOWEnddate,
      "NewSOW": this.associateVariableInfo.NewSOW,
      "Billable": this.associateVariableInfo.Billable,
      "RLGAccountYN": this.associateVariableInfo.RLGAccountYN,
      "RLGStaffID": this.associateVariableInfo.RLGStaffID,
      "CTSEL": this.associateVariableInfo.CTSEL,
      "RLGID": this.associateVariableInfo.RLGID,
      "RLGEmail": this.associateVariableInfo.RLGEmail,
      "RLGJoinDate": this.associateVariableInfo.RLGJoinDate,
      "RLGLeavingDate": this.associateVariableInfo.RLGLeavingDate,
      "RLGRprtMgr": this.associateVariableInfo.RLGRprtMgr,
      "AssetNoOnshore": this.associateVariableInfo.AssetNoOnshore,
      "VMNoOffshore": this.associateVariableInfo.VMNoOffshore,
      "Comments": this.associateVariableInfo.Comments,
      "PrimarySkill": this.associateVariableInfo.PrimarySkill,
      "Status": this.associateVariableInfo.Status,
    };

    this.spinnerService.show();
    var siteUrl = this.baseUrl + "_api/lists/getbytitle('" + this.listName + "')/items";
    this.httpClientService.httpPost(siteUrl, item, this.formDigestDetail.FormDigestValue).subscribe(() => {
      this.spinnerService.hide();
      this.toasterService.pop("success", "Associate Details", "Associate Details Added Successfully");
    }, error => {
      this.spinnerService.hide();
      this.toasterService.pop("error", "Associate Details", "Error Occurred While Adding Associate Details");
      console.log(error);
    });
  }

  public updateAssociateDetail() {
    var itemType = this.getItemTypeForListName(this.listName);
    var item = {
      "__metadata": { "type": itemType },
      "CognizantId": this.associateVariableInfo.CognizantId,
      "SkillSets": this.associateVariableInfo.SkillSets,
      "Location": this.associateVariableInfo.Location,
      "ESAPrjName": this.associateVariableInfo.ESAPrjName,
      "RsrcAllocEndDt": this.associateVariableInfo.RsrcAllocEndDt,
      "VIEndDtOnshore": this.associateVariableInfo.VIEndDtOnshore,
      "VIType": this.associateVariableInfo.VIType,
      "VIExtPosblByndEnddt": this.associateVariableInfo.VIExtPosblByndEnddt,
      "VIHwLngCanExt": this.associateVariableInfo.VIHwLngCanExt,
      "VIExtPosbleFrmUK": this.associateVariableInfo.VIExtPosbleFrmUK,
      "ResourceName": this.associateVariableInfo.ResourceName,
      "RateCardRole": this.associateVariableInfo.RateCardRole,
      "RateCardDayRate": this.associateVariableInfo.RateCardDayRate,
      "OnOff2017": this.associateVariableInfo.OnOff2017,
      "ProjectProgramme": this.associateVariableInfo.ProjectProgramme,
      "Portfolio": this.associateVariableInfo.Portfolio,
      "OldSOW": this.associateVariableInfo.OldSOW,
      "NewSOWEnddate": this.associateVariableInfo.NewSOWEnddate,
      "NewSOW": this.associateVariableInfo.NewSOW,
      "Billable": this.associateVariableInfo.Billable,
      "RLGAccountYN": this.associateVariableInfo.RLGAccountYN,
      "RLGStaffID": this.associateVariableInfo.RLGStaffID,
      "CTSEL": this.associateVariableInfo.CTSEL,
      "RLGID": this.associateVariableInfo.RLGID,
      "RLGEmail": this.associateVariableInfo.RLGEmail,
      "RLGJoinDate": this.associateVariableInfo.RLGJoinDate,
      "RLGLeavingDate": this.associateVariableInfo.RLGLeavingDate,
      "RLGRprtMgr": this.associateVariableInfo.RLGRprtMgr,
      "AssetNoOnshore": this.associateVariableInfo.AssetNoOnshore,
      "VMNoOffshore": this.associateVariableInfo.VMNoOffshore,
      "Comments": this.associateVariableInfo.Comments,
      "PrimarySkill": this.associateVariableInfo.PrimarySkill,
      "Status": this.associateVariableInfo.Status,
    };

    this.spinnerService.show();
    var siteUrl = this.baseUrl + "_api/lists/getbytitle('" + this.listName + "')/items(" + this.associateVariableInfo.Id + ")";
    this.httpClientService.httpMerge(siteUrl, item, this.formDigestDetail.FormDigestValue).subscribe(() => {
      this.spinnerService.hide();
      this.toasterService.pop("success", "Modify Assoiciate", "Associate Details Updated Successfully");
    }, error => {
      this.spinnerService.hide();
      this.toasterService.pop("error", "Modify Assoiciate", "Error Occurred While Updating Associate Details");
    });
  }

  public getItemTypeForListName(name) {
    return "SP.Data." + name.charAt(0).toUpperCase() + name.slice(1) + "ListItem";
  }

  onCancelClick() {
    this.dialogRef.close(true);
  }

  onOkClick() {
    if (this.isEditMode === true) {
      this.updateAssociateDetail();
    }
    else {
      this.addAssociateDetail();
    }
  }
}
