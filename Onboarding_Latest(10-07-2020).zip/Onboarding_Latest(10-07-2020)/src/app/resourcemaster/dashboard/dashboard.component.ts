import { Component, OnInit, ViewChild } from '@angular/core';
import { ResourceDetailService } from 'src/app/providers/service/resourceMaster/resourceDetail.service';
import { BasicInfo } from 'src/app/providers/model/basicInfo';
import { UserGroupNewService } from 'src/app/providers/service/onboarding/group-course/userGroup.service';
import { MainResourceList } from 'src/app/providers/model/MainResourceList';
import { MatTableDataSource, MatPaginator, MatDialog, MatSort } from '@angular/material';
import { ManageResourceComponent } from '../manage-resource/manage-resource.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { RateCardRole } from 'src/app/providers/model/RateCardRole';
import { forkJoin } from 'rxjs';
import { ProjectProgramme } from 'src/app/providers/model/ProjectProgramme';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class RMDashboardComponent implements OnInit {
  displayedColumns: string[] = ["CognizantId","CognizantName","CognizantGrade","ESAPrjName"];
  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: false}) sort: MatSort;
  resourceDetail: BasicInfo[] = [];
  masterinfo: MainResourceList[]=[];
  RateCardRole: RateCardRole[];
  ProjectProgram: ProjectProgramme[];
  dataSource:MatTableDataSource<BasicInfo>;
  constructor(private service: ResourceDetailService,
    public dialog: MatDialog,
    private spinnerService: Ng4LoadingSpinnerService ) { }

  ngOnInit() {
    this.getMetaData();
    this.getUserInfo();
  }

  getMetaData() {
    forkJoin([
      this.service.getRateCardRole(),
      this.service.getProjectProgram()
    ]).subscribe((response:Object) => {
      this.loadMetaData(response);
    });
  }

  loadMetaData(metaData: Object){
    this.RateCardRole = metaData[0];
    this.ProjectProgram = metaData[1];
  }

  getUserInfo(){
    this.spinnerService.show();
    this.service.getAllUserBasicData().subscribe((mainResourceList: MainResourceList[]) => {
      this.fetchData(mainResourceList);
    });
  }

  fetchData(mainResourceList:MainResourceList[]){
    this.masterinfo = mainResourceList;
    mainResourceList.forEach((element:MainResourceList) => {
      this.service.getUserDetail(element).subscribe((basicInfo: BasicInfo) => {
        this.addToList(basicInfo);
      });
    });
    this.spinnerService.hide();
  }

  addToList(res: BasicInfo){
    if(res.CognizantName){
      this.resourceDetail.push(res);
    }
    else {
      console.log(res.CognizantId);
    }
    this.addToTable();
    
  }

  addToTable(){
    this.dataSource = new MatTableDataSource(this.resourceDetail);
    this.dataSource.paginator=this.paginator;
    this.dataSource.sort = this.sort;
    this.dataSource.sortingDataAccessor = (item,property) => {
      switch(property) {
        case "CognizantName": return item.CognizantName;
        case "CognizantGrade": return item.CognizantGrade;
        default: return item[property];
      }
    };
  }

  applyFilter(value: string) {
    this.dataSource.filter = value.trim().toLowerCase();
    if(this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  ViewAssociateData(row:BasicInfo){
    let masterdata = this.masterinfo.find(resource => resource.CognizantId === row.CognizantId);
    this.dialog.open(ManageResourceComponent,
      {
        height:"430px",
        width:"1100px",
        data: {
          rateCardRole: this.RateCardRole,
          projectProgramme: this.ProjectProgram,
          basicInfo:row,
          detailedInfo:masterdata
        }
      });
  }

  addAssociate(){
    this.dialog.open(ManageResourceComponent,
      {
        height:"430px",
        width:"1100px",
        data: {
          rateCardRole: this.RateCardRole,
          projectProgramme: this.ProjectProgram,
          basicInfo: null, detailedInfo: null
        }
      });
  }
}
