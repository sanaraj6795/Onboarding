import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { BsDatepickerModule, PaginationModule, BsModalService, ProgressbarModule } from 'ngx-bootstrap';
import { ChartsModule } from 'ng2-charts';
import { ToasterModule } from 'angular2-toaster';

import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from '../app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ResourceMasterRoutingModule } from './resourcemaster-routing.module';
import { RMDashboardComponent } from './dashboard/dashboard.component';
import { ResourceDetailService } from '../providers/service/resourceMaster/resourceDetail.service';
import { MatTableModule, MatPaginatorModule, MatTabsModule, MatButtonModule, MatIconModule, MatFormField, MatInputModule, MatSortModule } from '@angular/material';
import { ManageResourceComponent } from './manage-resource/manage-resource.component';
import { DatePipe } from '@angular/common';


@NgModule({
  declarations: [
    RMDashboardComponent,
    ManageResourceComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    ChartsModule,
    Ng4LoadingSpinnerModule.forRoot(),
    BsDatepickerModule.forRoot(),
    PaginationModule.forRoot(),
    ProgressbarModule.forRoot(),
    ToasterModule.forRoot(),
    ResourceMasterRoutingModule,
    MatTableModule,
    MatPaginatorModule,
    MatTabsModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule
  ],
  providers: [
    DatePipe,
    BsModalService,
    ResourceDetailService
  ],
  entryComponents: [
  ]
})
export class ResourceMasterModule { }
