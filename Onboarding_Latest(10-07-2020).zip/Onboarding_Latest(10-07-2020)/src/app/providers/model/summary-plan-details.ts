export interface ISummaryPlanDetails {
    AssociateId: string,
    Name: string,
    Title: string,
    OnboardingStatus: string,
    CompletionPercentage: string,
    StartDate: string
    CompletionDate: string
}

export class SummaryPlanDetails implements ISummaryPlanDetails {
    constructor(
        public AssociateId: string,
        public Name: string,
        public Title: string,
        public OnboardingStatus: string,
        public CompletionPercentage: string,
        public StartDate: string,
        public CompletionDate: string) {
    }
}

export interface ISummaryPlanDetailsResponse {
    summaryDetails:ISummaryPlanDetails[],
    count: number
}

export class SummaryPlanDetailsResponse implements ISummaryPlanDetailsResponse {

    constructor(
        public summaryDetails:ISummaryPlanDetails[],
        public count: number) {
    }
}