import { UserProfileProperties } from './userprofileproperties';

export class BasicInfo {
    CognizantId: number;
    CognizantName: string;
    CognizantGrade: string;
    ESAPrjName:string;
    OtherDetails: UserProfileProperties[];
}