export interface IAllList {
    id: string,
    name: string,
    checked: boolean
}

export class AllList implements IAllList {

    constructor(
        public id: string,
        public name: string,
        public checked: boolean) {
    }
}