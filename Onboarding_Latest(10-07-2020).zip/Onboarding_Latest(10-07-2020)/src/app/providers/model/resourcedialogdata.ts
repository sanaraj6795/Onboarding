import { BasicInfo } from './basicInfo';
import { MainResourceList } from './MainResourceList';
import { RateCardRole } from './RateCardRole';
import { ProjectProgramme } from './ProjectProgramme';

export class ResourceDialogData {
    rateCardRole: RateCardRole;
    projectProgramme: ProjectProgramme;
    basicInfo:BasicInfo;
    detailedInfo:MainResourceList;
}