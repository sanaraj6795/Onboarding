export interface IGroupCourse {
    day:number,
    week:string,
    startDate:string,
    courseType:string,
    title:string,
    url:string,
    courseCode:string,
    documentType:string,
    isDayChangeDisabled?:boolean;
}