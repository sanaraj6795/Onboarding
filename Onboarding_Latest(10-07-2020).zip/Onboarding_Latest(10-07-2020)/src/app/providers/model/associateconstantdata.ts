export class AssociateConstantData {
    Email: string;
    Department: string; 
    CtsLineManager:string;
}