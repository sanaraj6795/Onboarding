export class ESAProject{
    ESAProjectId: number;
    ESAProjectName: string;
}