export class ProjectProgramme {
    ProjectProgramId: number;
    Title: string;
}