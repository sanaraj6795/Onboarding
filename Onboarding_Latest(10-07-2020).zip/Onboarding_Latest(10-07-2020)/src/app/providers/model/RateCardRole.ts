export class RateCardRole{
    RateCardRoleId: number;
    RoleInRateCard: string;
}