export class UserProfileProperties {
    Key: string;
    Value: string;
    ValueType: string;
}