export interface ISkillSet {
    id: string,
    associateId: string,
    skills: string
}

export class SkillSet implements ISkillSet {

    constructor(
        public id: string,
        public associateId: string,
        public skills: string) {
    }
}