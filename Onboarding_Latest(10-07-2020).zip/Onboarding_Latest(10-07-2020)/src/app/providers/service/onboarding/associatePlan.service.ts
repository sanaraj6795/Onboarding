import { Injectable } from '@angular/core';
import { map, concatMap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import * as moment from 'moment'
import { environment } from 'src/environments/environment.prod';
import { HttpClientService } from '../http-client.service';

@Injectable()
export class AssociatePlanService {
    userInfo: any;
    baseUrl = environment.apiBaseUrl;

    constructor(private httpClientService: HttpClientService) {
    }

    getSummary(associateID: string): Observable<any> {
        var apiURL = this.baseUrl + `_api/lists/getbytitle('OnboardingPlanDetail')/items?$filter=AssociateID eq ${associateID}`;
        return this.httpClientService.httpGet(apiURL).pipe(map((response: any) => {
            return of(response.value);
        }));
    }

    getUserInfo() {
        const siteUrl = this.baseUrl + "_api/SP.UserProfiles.PeopleManager/GetMyProperties";
        return this.httpClientService.httpGet(siteUrl);
    }

    uploadDate({ id, completionDate }: { id: number; completionDate: Date; }, formDigestValue: any): Observable<any> {
        let listName = "OnboardingPlanDetail";
        var itemType = this.getItemTypeForListName(listName);
        var item = {
            "__metadata": { "type": itemType },
            "CompletionDate": completionDate
        };

        var siteUrl = this.baseUrl + `_api/lists/getbytitle('OnboardingPlanDetail')/items(${id})`;
        return this.httpClientService.httpMerge(siteUrl, item, formDigestValue);
    }

    getAttachmentFilesCourseById(planDetailId: number): Observable<any> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('OnboardingPlanDetail')/items(" + planDetailId + ")/AttachmentFiles";
        return this.httpClientService.httpGet(apiURL).pipe(map((resspone: any) => {
            if (resspone && resspone.value && resspone.value.length > 0) {
                return of({ "FileName": resspone.value[0].FileName, "isFile": true });
            }

            return of({ "isFile": false });
        }));
    }

    deleteFile(planDetailId: number, fileName: any, formDigestValue: any): Observable<any> {
        var siteUrl = this.baseUrl + "_api/web/lists/GetByTitle('OnboardingPlanDetail')/GetItemById(" + planDetailId + ")/AttachmentFiles/getByFileName('" + fileName + "')  ";
        return this.httpClientService.httpDelete(siteUrl, formDigestValue);
    }

    updatePlanSummary(associateId: any, completionPercentage: any, formDigestValue: any): Observable<any> {
        let listName = "OnboardingPlanSummary";
        var itemType = this.getItemTypeForListName(listName);

        let completionDate = null;
        let completionStatus = "InProgress";
        if (completionPercentage === "100") {
            completionDate = moment(new Date).format('DD/MM/YYYY').toString(),
                completionStatus = "Completed";
        }

        var item = {
            "__metadata": { "type": itemType },
            "CompletionPercentage": completionPercentage,
            "CompletionDate": completionDate,
            "OnboardingStatus": completionStatus
        };

        var apiURL = this.baseUrl + "_api/lists/getbytitle('OnboardingPlanSummary')/items?$filter=Title eq " + associateId;
        return this.httpClientService.httpGet(apiURL).pipe(concatMap((planSummaryResponse: any) => {
            if (planSummaryResponse && planSummaryResponse.value && planSummaryResponse.value.length >= 0) {
                const planSummary = planSummaryResponse.value[0];
                var siteUrl = this.baseUrl + `_api/lists/getbytitle('OnboardingPlanSummary')/items(${planSummary.ID})`;
                return this.httpClientService.httpMerge(siteUrl, item, formDigestValue);
            }

            return of(null);
        }));
    }

    viewAttachmentFilesById(id: number): Observable<any> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('OnboardingPlanDetail')/items(" + id + ")/AttachmentFiles";
        return this.httpClientService.httpGet(apiURL).pipe(concatMap((planResponse: any) => {
            if (planResponse && planResponse.value && planResponse.value.length >= 0) {
                const fileDetail = planResponse.value[0];
                var apiURL = this.baseUrl + "Lists/OnboardingPlanDetail/Attachments/" + id + "/" + fileDetail.FileName + "";
                return this.httpClientService.getArrayBuffer(apiURL).pipe(map((resspone: any) => {
                    return of(resspone);
                }));
            }

            return of(null);
        }));
    }

    private getItemTypeForListName(name) {
        return "SP.Data." + name.charAt(0).toUpperCase() + name.slice(1) + "ListItem";
    }

    private handleError(error: Response) {
        return Observable.throw(error.json() || 'Server Error');
    }
}