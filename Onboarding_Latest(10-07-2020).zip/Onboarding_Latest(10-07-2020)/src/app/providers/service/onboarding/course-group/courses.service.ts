import { Injectable } from '@angular/core';
import { forkJoin } from 'rxjs';
import { map } from 'rxjs/operators';
import { UserGroup, UserGroupResponse } from 'src/app/providers/model/user-group';
import { environment } from 'src/environments/environment.prod';
import { HttpClientService } from '../../http-client.service';

@Injectable()
export class CoursesService {

  baseUrl = environment.apiBaseUrl;

  constructor(private httpClientService: HttpClientService) {
  }

  getCourseGroup(startItem: any) {
    var apiURL = this.baseUrl + "_api/lists/getbytitle('OnboardingCourseGroup')/items?%24skiptoken=Paged%3dTRUE%26p_ID%3d" + startItem + "&%24top=10";
    var apiURLLast = this.baseUrl + "_api/lists/getbytitle('OnboardingCourseGroup')/items?$top=1&$select=Id&$orderby=Created%20desc";
    let getCourses = this.httpClientService.httpGet(apiURL);
    let getCoursesCountLast = this.httpClientService.httpGet(apiURLLast);

    return forkJoin([getCourses, getCoursesCountLast]).pipe(map((resspone: any) => {
      const courseDetails = resspone[0].value.map(item => {
        return new UserGroup(
          item.ID,
          item.Title,
          item.GroupCode,
          item.GroupDescription,
          item.CourseIds
        );
      });

      return new UserGroupResponse(courseDetails, this.getCoursesCountLast(resspone[1]));
    }));
  }

  private getCoursesCountLast(resspone: any): any {
    if (resspone && resspone.value.length != 0) {
      return resspone.value[0].Id
    }
    return 0;
  }
}
