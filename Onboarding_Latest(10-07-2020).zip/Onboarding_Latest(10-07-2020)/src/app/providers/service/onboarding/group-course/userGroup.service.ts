import { Injectable } from '@angular/core';
import { Observable, of, forkJoin } from 'rxjs';
import { map, concatMap } from 'rxjs/operators';
import { Role } from 'src/app/providers/model/role';
import { UserDetail } from 'src/app/providers/model/userDetail';
import { SummaryPlanDetails, SummaryPlanDetailsResponse } from 'src/app/providers/model/summary-plan-details';
import { environment } from 'src/environments/environment.prod';
import { HttpClientService } from '../../http-client.service';

@Injectable()
export class UserGroupNewService {

    baseUrl = environment.apiBaseUrl;

    constructor(private httpClientService: HttpClientService) {
    }

    getRoleOptions(): Observable<any> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('OnboardingCourseGroup')/items?%24skiptoken=Paged%3dTRUE%26p_ID%3d";
        return this.httpClientService.httpGet(apiURL).pipe(map((resspone: any) => {
            const roleOptions = resspone.value.map(item => {
                return new Role(
                    item.CourseIds,
                    item.GroupCode,
                    item.Title,
                );
            });
            return of(roleOptions);
        }));
    }

    getUserDetail(userId: any): Observable<any> {
        var apiURL = this.baseUrl + "_api/SP.UserProfiles.PeopleManager/GetPropertiesFor(accountName=@v)?@v='i:0%23.f|membership|" + userId + "@cognizant.com'&$select=DisplayName,Email,Title";
        return this.httpClientService.httpGet(apiURL).pipe(map((resspone: any) => {
            if (resspone && resspone.DisplayName) {
                const userDetails = new UserDetail(
                    resspone.DisplayName,
                    resspone.Email,
                    resspone.Title,
                    userId
                );
                return of(userDetails);
            }
            return of(null);
        }));
    }

    getPlanSummaryDetail(associateId: any, startItem: any): Observable<any> {
        var apiURL = associateId ? this.baseUrl + "_api/lists/getbytitle('OnboardingPlanSummary')/items?$filter=Title eq " + associateId :
            this.baseUrl + "_api/lists/getbytitle('OnboardingPlanSummary')/items?%24skiptoken=Paged%3dTRUE%26p_ID%3d" + startItem + "&%24top=10";
        var apiURLLast = this.baseUrl + "_api/lists/getbytitle('OnboardingPlanSummary')/items?$top=1&$select=Id&$orderby=Created%20desc";
        let getCourses = this.httpClientService.httpGet(apiURL);
        let getCoursesCountLast = this.httpClientService.httpGet(apiURLLast);     
        let planSummary = [];

        return forkJoin([getCourses, getCoursesCountLast]).pipe(concatMap((planSummaryResponse: any) => {
            if (planSummaryResponse[0].value.length === 0) {
                return of(new SummaryPlanDetailsResponse([], 0));
            }

            planSummary = planSummaryResponse[0].value;
            var associateIds = planSummaryResponse[0].value.map(item => { return item.Title });
            const calls = [];
            associateIds.forEach((associateId) => {
                var apiURL = this.baseUrl + "_api/SP.UserProfiles.PeopleManager/GetPropertiesFor(accountName=@v)?@v='i:0%23.f|membership|" + associateId + "@cognizant.com'&$select=DisplayName,Email,Title";
                calls.push(this.httpClientService.httpGet(apiURL));
            });

            return forkJoin(calls).pipe(map((response: any) => {
                const courseDetails = response.map((item, index) => {
                    return new SummaryPlanDetails(
                        planSummary[index].Title,
                        item.DisplayName,
                        item.Title,
                        planSummary[index].OnboardingStatus,
                        planSummary[index].CompletionPercentage,
                        planSummary[index].StartDate,
                        planSummary[index].CompletionDate
                    );
                });

                return new SummaryPlanDetailsResponse(courseDetails,  this.getCoursesCountLast(planSummaryResponse[1]));
            }));
        }));
    }

    getHolidayPlans(): Observable<any> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('OnboardingLeaveTracker')/items?%24skiptoken=Paged%3dTRUE%26p_ID%3d";
        return this.httpClientService.httpGet(apiURL).pipe(map((resspone: any) => {
            const options = resspone.value.map(item => item.Date);
            return of(options);
        }));
    }

    private getCoursesCountLast(resspone: any): any {
        if (resspone && resspone.value.length != 0) {
            return resspone.value[0].Id
        }
        return 0;
    }

}