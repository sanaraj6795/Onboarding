import { Injectable } from '@angular/core';
import { Observable, of, forkJoin } from 'rxjs';
import { map } from 'rxjs/operators';
import { CourseDetail, CourseResponse, ICourseDetail } from 'src/app/providers/model/courseDetail';
import { environment } from 'src/environments/environment.prod';
import { HttpClientService } from '../http-client.service';

@Injectable()
export class CourseDetailsService {

    baseUrl = environment.apiBaseUrl;

    constructor(private httpClientService: HttpClientService) {
    }

    getCourses(startItem: any, currentItem: any) {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('OnboardingCourseDetail')/items?%24skiptoken=Paged%3dTRUE%26p_ID%3d" + startItem + "&%24top=10";
        // var apiURL = this.baseUrl + "_api/lists/getbytitle('OnboardingCourseDetail')/items?$filter=Id gt " + currentItem + "&%24top=10";
        var apiURLLast = this.baseUrl + "_api/lists/getbytitle('OnboardingCourseDetail')/items?$top=1&$select=Id&$orderby=Created%20desc";
        let getCourses = this.httpClientService.httpGet(apiURL);
        let getCoursesCountLast = this.httpClientService.httpGet(apiURLLast);

        return forkJoin([getCourses, getCoursesCountLast]).pipe(map((resspone: any) => {
            const courseDetails = resspone[0].value.map(item => {
                return new CourseDetail(
                    item.ID,
                    item.Title,
                    item.Code,
                    item.Reference,
                    item.Description,
                    item.CourseType,
                    item.DocumentType
                );
            });

            return new CourseResponse(courseDetails, this.getCoursesCountLast(resspone[1]));
        }));
    }

    getCourseType(): Observable<any> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('OnboardingCourseDetail')/items?$select=CourseType";

        return this.httpClientService.httpGet(apiURL).pipe(map((response: any) => {
            let courseType = [...new Set(response.value.map(item => item.CourseType))];
            return of(courseType);
        }));
    }

    getCourseById(courseId?: string): Observable<any> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('OnboardingCourseDetail')/items(" + courseId + ")";
        return this.httpClientService.httpGet(apiURL).pipe(map((resspone: any) => {
            const courseDetails = new CourseDetail(
                resspone.ID,
                resspone.Title,
                resspone.Code,
                resspone.Reference,
                resspone.Description,
                resspone.CourseType,
                resspone.DocumentType
            );

            return of(courseDetails);
        }));
    }

    getCourseSearch(searchValue: string, type: string): Observable<CourseDetail[]> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('OnboardingCourseDetail')/items?$filter=(startswith(Title,%27" + searchValue + "%27)%20and%20(CourseType%20eq%20%27" + type + "%27))";
        return this.httpClientService.httpGet(apiURL).pipe(map((resspone: any) => {
            return resspone.value.map(item => {
                return new CourseDetail(
                    item.ID,
                    item.Title,
                    item.Code,
                    item.Reference,
                    item.Description,
                    item.CourseType,
                    item.DocumentType
                );
            });
        }));
    }

    getAllCourse(): Observable<any> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('OnboardingCourseDetail')/items?$top=1000";
        return this.httpClientService.httpGet(apiURL).pipe(map((resspone: any) => {
            const courseDetails = resspone.value.map(item => {
                return new CourseDetail(
                    item.ID,
                    item.Title,
                    item.Code,
                    item.Reference,
                    item.Description,
                    item.CourseType,
                    item.DocumentType
                );
            });

            return of(courseDetails);
        }));
    }

    post(model: ICourseDetail): Observable<ICourseDetail> {
        return of(null);
    }


    put(model: ICourseDetail): Observable<ICourseDetail> {
        return of(null);
    }

    delete(id: string): Observable<ICourseDetail> {
        return of(null);
    }

    private handleError(error: any) {
        console.log(error);
        return Observable.throw(error.json().error || 'Server Error');
    }

    private getCoursesCountLast(resspone: any): any {
        if (resspone && resspone.value.length != 0) {
            return resspone.value[0].Id
        }
        return 0;
    }
}