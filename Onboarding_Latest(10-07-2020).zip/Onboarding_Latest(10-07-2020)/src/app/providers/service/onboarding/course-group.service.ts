import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { map, concatMap } from 'rxjs/operators';
import { ICourse } from 'src/app/providers/model/course';
import { IUserGroup, UserGroup, GetUserGroupResponse } from 'src/app/providers/model/user-group';
import { CourseDetail } from 'src/app/providers/model/courseDetail';
import { environment } from 'src/environments/environment.prod';
import { HttpClientService } from '../http-client.service';

@Injectable()
export class CourseGroupService {
  courses: ICourse[];
  baseUrl = environment.apiBaseUrl;

  constructor(private httpClientService: HttpClientService) {
  }


  get(): Observable<IUserGroup[]> {
    return of(this.getResponse());
  }

  getCourseById(courseId?: string): Observable<any> {
    var apiURL = this.baseUrl + "_api/lists/getbytitle('OnboardingCourseGroup')/items(" + courseId + ")";

    return this.httpClientService.httpGet(apiURL).pipe(
      concatMap((courseGroupDetail: any) => this.secondPOSTCallToAPI(courseGroupDetail.CourseIds.split(',')).pipe(map(
        (resspone: any) => {
          const userGroup = new UserGroup(
            courseGroupDetail.ID,
            courseGroupDetail.Title,
            courseGroupDetail.GroupCode,
            courseGroupDetail.GroupDescription,
            courseGroupDetail.CourseIds
          );
          const courseDetails = resspone.value.map(item => {
            return new CourseDetail(
              item.ID,
              item.Title,
              item.Code,
              item.Reference,
              item.Description,
              item.CourseType,
              item.DocumentType
            );
          });

          const getUserGroupResponse = new GetUserGroupResponse(userGroup, courseDetails);

          return of(getUserGroupResponse);
        }
      )))
    );
  }

  getCourseDetailsByIds(courseIds?: string): Observable<any> {
    let courseIdOrder=courseIds.split(',');
    let CourseDetailsOrder:CourseDetail[]=[];
    return this.secondPOSTCallToAPI(courseIds.split(',')).pipe(map(
      (resspone: any) => {
        const courseDetails = resspone.value.map(item => {
          return new CourseDetail(
            item.ID,
            item.Title,
            item.Code,
            item.Reference,
            item.Description,
            item.CourseType,
            item.DocumentType
          );
        });
        courseIdOrder.forEach(x=>{
          courseDetails.forEach(y=>{
              if(y.id==x)
              {
              CourseDetailsOrder.push(y);
              }
          });
          });
          return of(CourseDetailsOrder);
      })
    );
  }

  private secondPOSTCallToAPI(courseIds: any) {
    let courseIdsG = "";
    courseIds.forEach((courseIdNew, index, array) => {
      if (index === (array.length - 1)) {
        courseIdsG = courseIdsG + "(Id eq " + courseIdNew + ")";
      } else if (courseIdsG) {
        courseIdsG = courseIdsG + "(Id eq " + courseIdNew + ") or";
      } else {
        courseIdsG = "(Id eq " + courseIdNew + ") or";
      }
    });

    var apiURL = this.baseUrl + "_api/lists/getbytitle('OnboardingCourseDetail')/items?$filter=(" + courseIdsG + ")";
    return this.httpClientService.httpGet(apiURL);
  }


  private handleError(error: Response) {
    console.error(error);
    return Observable.throw(error.json() || 'Server error');
  }

  private getResponse(): IUserGroup[] {

    const first = { GroupId: "1", GroupName: "Developer", GroupCode: "A", GroupDescription: "Project 1" };
    const second = { GroupId: "2", GroupName: "Automation Tester", GroupCode: "B", GroupDescription: "Project 2" };
    const third = { GroupId: "3", GroupName: "Manual Tester", GroupCode: "C", GroupDescription: "Project 3" };

    return [first, second, third] as IUserGroup[];
  }
}