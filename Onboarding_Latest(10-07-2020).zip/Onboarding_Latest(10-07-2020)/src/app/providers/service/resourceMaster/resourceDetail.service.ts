import { Injectable } from '@angular/core';
import { map, concat } from 'rxjs/operators';
import { Observable, forkJoin } from 'rxjs';
import { BasicInfo } from '../../model/basicInfo';
import { MainResourceList } from '../../model/MainResourceList';
import { ESAProject } from '../../model/ESAProject';
import { RateCardRole } from '../../model/RateCardRole';
import { ProjectProgramme } from '../../model/ProjectProgramme';
import { environment } from 'src/environments/environment.prod';
import { HttpClientService } from '../http-client.service';

@Injectable()
export class ResourceDetailService {

    baseUrl = environment.apiBaseUrl;

    constructor(private httpClientService: HttpClientService) {
    }
    getUserDetail(user: MainResourceList): Observable<BasicInfo> {
        var apiURL = this.baseUrl + "_api/SP.UserProfiles.PeopleManager/GetPropertiesFor(accountName=@v)?@v='i:0%23.f|membership|" + user.CognizantId + "@cognizant.com'&$select=DisplayName,Title,UserProfileProperties";
        return this.httpClientService.httpGet(apiURL).pipe(map((response: any) => {
            if (response) {
                const userDetails: BasicInfo = {
                    CognizantId: user.CognizantId,
                    CognizantName: response.DisplayName,
                    CognizantGrade: response.Title,
                    ESAPrjName: user.ESAPrjName,
                    OtherDetails: response.UserProfileProperties
                };
                return userDetails;
            }
            return null;
        }));
    }

    getAllUserBasicData(): Observable<MainResourceList[]> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('ResourceMasterAssociateDetails')/items?$top=1000";
        return this.httpClientService.httpGet(apiURL).pipe(map((respone: any) => {
            if (respone && respone.value) {
                return respone.value;
            }
            return [];
        }));
    }

    getESAProject(): Observable<ESAProject[]> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('ESAProject')/items";
        return this.httpClientService.httpGet(apiURL).pipe(map((respone: any) => {
            if (respone && respone.value) {
                return respone.value;
            }
            return [];
        }));
    }

    getProjectProgram(): Observable<ProjectProgramme[]> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('ProjectProgram')/items";
        return this.httpClientService.httpGet(apiURL).pipe(map((respone: any) => {
            if (respone && respone.value) {
                return respone.value;
            }
            return [];
        }));
    }

    getRateCardRole(): Observable<RateCardRole[]> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('RateCardRole')/items";
        return this.httpClientService.httpGet(apiURL).pipe(map((respone: any) => {
            if (respone && respone.value) {
                return respone.value;
            }
            return [];
        }));
    }
}