import { Pipe, PipeTransform } from '@angular/core'
import * as moment from 'moment'

@Pipe({
    name: 'formatDate'
})
export class DatePipe implements PipeTransform {
    transform(date: any, args?: any): any {
        const isValidCompletionDate = moment(date).isValid();
        if (isValidCompletionDate) {
            return moment(date).format('DD/MM/YYYY');
        }
        return null;
    }
}