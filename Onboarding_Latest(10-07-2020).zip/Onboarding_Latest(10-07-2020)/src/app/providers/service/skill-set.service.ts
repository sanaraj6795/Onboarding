import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { SkillSet } from '../model/skill-set';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment.prod';
import { HttpClientService } from './http-client.service';

@Injectable({
  providedIn: 'root'
})
export class SkillSetService {

  baseUrl = environment.apiBaseUrl;

  constructor(private httpClientService: HttpClientService) {
  }

  getUserById(userId: any): Observable<any> {
    var apiURL = this.baseUrl + "_api/lists/getbytitle('OnboardingSkillSet')/items?$filter=AssociateID eq " + userId;
    return this.httpClientService.httpGet(apiURL).pipe(map((response: any) => {
      if (response && response.value.length > 0) {
        const skillSetDetails = new SkillSet(
          response.value[0].ID,
          response.value[0].AssociateID,
          response.value[0].SkillSet
        );
        return of(skillSetDetails);
      }
      return of(null);
    }));
  }

  getUserDetailsById(userId: any): Observable<any> {
    var apiURL = this.baseUrl + "_api/lists/getbytitle('ResourceMasterAssociateDetails')/items?$filter=CognizantId eq " + userId;
    return this.httpClientService.httpGet(apiURL).pipe(map((response: any) => {
      if (response && response.value.length > 0) {
        return of(response.value[0]);
      }
      return of(null);
    }));
  }

}