import { NgModule } from '@angular/core';

import { UserInfoService } from './service/user-info.service';
import { ToasterService } from 'angular2-toaster';
import { UserGroupNewService } from './service/onboarding/group-course/userGroup.service';
import { BsModalService } from 'ngx-bootstrap';
import { CoursesService } from './service/onboarding/course-group/courses.service';
import { DashboardService } from './service/dashboard.service';

import { CourseDetailsService } from './service/onboarding/course-details.service';
import { CourseGroupService } from './service/onboarding/course-group.service';
import { AssociatePlanService } from './service/onboarding/associatePlan.service';
import { SkillSetService } from './service/skill-set.service';
import { ResourceDetailService } from './service/resourceMaster/resourceDetail.service';

@NgModule({
    imports: [

    ],
    providers: [
        CourseDetailsService,
        CourseGroupService,
        UserInfoService,
        ToasterService,
        UserInfoService,
        DashboardService,
        CoursesService,
        BsModalService,
        UserGroupNewService,
        AssociatePlanService,
        SkillSetService,
        ResourceDetailService
    ]
})
export class ProvidersModule { }
